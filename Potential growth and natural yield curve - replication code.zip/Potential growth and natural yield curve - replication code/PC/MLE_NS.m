function MLE_NS(yields,options1,optimize,initialization,ploting,save_output)
% This function runs a MLE/MAP estimation of the Nelson-Siegel model

disp('*****************************************');
disp('START of estimation Nelson-Siegel factors');
disp('*****************************************'); 
disp('->');

%% Prior
prior_shape=2; % shape inverse gamma distribution (the higher, the more informative)

% Extract dates and yields maturity (same for nominal and real)
[data,~,~] = xlsread('data.xls','real_yields'); % PC
%data=readmatrix('data.xls','Sheet','real_yields','Range','A1:K361'); % MAC
dates=data(2:end,1);
maturities=data(1,2:end)';

N=size(yields,2);
nmax=max(maturities);

% Extract parameters starting values from the Excel spreadsheet parameters
% Prior tightness and variance
[prior_hyper,~,~] = xlsread('parameters','NS','C4:C32'); % PC
%prior_hyper=readmatrix('parameters.xls','Sheet','NS','Range','C4:C32'); % MAC
if (initialization==0) || (optimize==0)
    [Omega0,~,~] = xlsread('parameters','NS','D4:D32'); % PC
    %Omega0=readmatrix('parameters.xls','Sheet','NS','Range','D4:D32'); % MAC
    [~,prior_beliefs,X0]=init_val_NS(yields,maturities);
else
    [Omega0,prior_beliefs,X0]=init_val_NS(yields,maturities);
    ENERGY=KF_NS(Omega0,maturities,yields,X0,prior_hyper,prior_shape,prior_beliefs,0,0);
    DNS_OLS=KF_NS(Omega0,maturities,yields,X0,prior_hyper,prior_shape,prior_beliefs,0,1);
    RMSE_OLS=DNS_OLS(end,end);
    xlswrite('parameters',[RMSE_OLS;-ENERGY;Omega0],'NS','B2:B32'); % PC
    %writematrix([RMSE_OLS;-ENERGY;Omega0],'parameters.xls','Sheet','NS','Range','B2:B32'); % MAC
end
    
if optimize~=0 % Start MLE/Bayesian estimation
    if optimize==1
        disp('Starting ML estimation');
    else
        disp('Starting Bayesian estimation');
    end
    % Constraints on variance terms (must be positive)
    [lb,ub]=restrictions(Omega0,'NS');
    startTic=tic;
    epsilon = 1e3;
    while epsilon > 1e-5
        Omega=fmincon(@(Omega)KF_NS(Omega,maturities,yields,X0,prior_hyper,prior_shape,prior_beliefs,optimize,0),Omega0,[],[],[],[],lb,ub,[],options1);      
        epsilon = abs(Omega-Omega0);
        epsilon = max(epsilon);
        Omega0=Omega;
    end
    [Omega0,ENERGY,~,~,Gradient,Hessian]=fminunc(@(Omega)KF_NS(Omega,maturities,yields,X0,prior_hyper,prior_shape,prior_beliefs,optimize,0),Omega0);
    time_elapsed=toc(startTic);
    disp('Optimization done');
    disp('Time needed in seconds for optimization is');
    disp(time_elapsed)
    disp('Energy value for Nelson-Siegel model is');
    disp(ENERGY);
    disp('(Penalized) likelihood value for Nelson-Siegel model is');
    disp(-ENERGY);  
    
    % Compute Standard Errors
    [ste,robust_ste,z_ratio,pvalues]=standard_error(Omega0,Gradient,Hessian);
end

% Compute DNS with optimized parameters
disp('Computation of final results');
DNS=KF_NS(Omega0,maturities,yields,X0,prior_hyper,prior_shape,prior_beliefs,optimize,1);
Level=DNS(:,1);
Slope=DNS(:,2);
Curvature=DNS(:,3);
RMSE=DNS(end,end);

% Recover r
[NS_yields_all,NS_yields,Loadings]=NS_pricing(Omega0(end),size(dates,1),N,maturities,[Level,Slope,Curvature]);
r_fitted=NS_yields(:,1);
% Convert to Quarterly (suppose first observation is a beginning of a quarter)
j=1;
for i=1:3:size(r_fitted)
    r_fitted_Q(j,1)=mean(r_fitted(i:i+2,1));
    j=j+1;
end    

% Statistics
data_for_stat=[yields,Level,Slope,Curvature];
maxi=max(data_for_stat,[],1);
mini=min(data_for_stat,[],1);
average=mean(data_for_stat,1);
standard_dev=std(data_for_stat,0,1);
acf1=[];
acf2=[];
acf3=[];
for i=1:N+3
    autocorrel=autocorr(data_for_stat(:,i),30);
    acf1=[acf1;autocorrel(2)];
    acf2=[acf2;autocorrel(11)];
    acf3=[acf3;autocorrel(31)];
end
%statistics=roundnum2cell([average',standard_dev',mini',maxi',acf1,acf2,acf3],3);
statistics=[average',standard_dev',mini',maxi',acf1,acf2,acf3];

% Re-write the optimized parameters on Excel
if optimize==1 || optimize==2
    xlswrite('parameters',[RMSE;-ENERGY;Omega0],'NS','D2:D32'); % PC
    xlswrite('parameters',[ste,z_ratio,pvalues],'NS','E4:G32'); % PC
    xlswrite('results',[Level,Slope,Curvature],'Real factors','B2:E352'); % PC
    xlswrite('results',statistics,'Statistics Real factors','B2:H14'); % PC
    xlswrite('results',r_fitted_Q(2:end,1),'r and r_star','B2:B121'); % PC
    %writematrix([RMSE;-ENERGY;Omega0],'parameters.xls','Sheet','NS','Range','D2:D32'); % MAC
    %writematrix([ste,z_ratio,pvalues],'parameters.xls','Sheet','NS','Range','E4:F32'); % MAC
    %writematrix([Level,Slope,Curvature],'results.xls','Sheet','Real factors','Range','B2:E361'); % MAC
    %writematrix(statistics,'results.xls','Sheet','Statistics Real factors','Range','B2:H14'); % MAC
    %writematrix(r_fitted_Q(18:end,1),'results.xls','Sheet','r and r_star','Range','B2'); % MAC
    disp('Parameters saved');
    disp('Yield curve factors saved');
else
    disp('Parameters and results not saved');
end

disp('RMSE for Nelson-Siegel model is:');
disp(RMSE);

clear data names epsilon DNS optimize

disp('->');
disp('******************************************');
disp('END of estimation of Nelson-Siegel factors');
disp('******************************************');
 

%% Plot
% Different monetary regimes
regimes(1,:)=[dates(1,1),1999.08]; % Pre-regimes
regimes(2,:)=[1999.17,2000.50]; % ZIRP
regimes(3,:)=[2001.25,2006.17]; % QE
regimes(4,:)=[2010.83,2013.25]; % CME
regimes(5,:)=[2013.33,2016]; % QQE
regimes(6,:)=[2016.75,2020]; % QQE with yield curve control
regimes_names={'Pre-regimes';'ZIRP';'QE';'CME';'QQE';'QQE with yield curve control'};

if ploting==1
    graphs(dates,maturities,N,[NS_yields,yields,NS_yields-yields],'Real yield curves',1,0,save_output) % yield curves
    graphs(dates,[1:1:nmax]',N,NS_yields_all,'Fitted real yield surface',2,0,save_output) % Plot fitted yield surface
    j=0;
    for i=regimes(:,1)'
        j=j+1;
        starting=find(dates(:,1)==i);
        end_date=regimes(j,2);
        ending=find(dates(:,1)==end_date);
        graphs(dates(starting:ending,1),maturities,N,NS_yields_all(starting:ending,:),char(strcat('Real yield curves quartiles',' (',regimes_names(j),')')),4,0,save_output) % Plot Quartiles of fitted yield curve
    end
    graphs(dates,maturities,N,NS_yields,'Maturities across the sample',7,0,save_output) % Plot all fitted maturities across the sample
    graphs([],maturities,N,Loadings,'Loadings',8,0,save_output) % Plot Loadings
    graphs(dates,[],N,[Level,Slope,Curvature],'Nelson-Siegel Factors',3,0,save_output) % Plot Level, Slope, Curvature   
end