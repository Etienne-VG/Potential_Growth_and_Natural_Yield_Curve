function MLE_MODEL(Ryields,options1,options2,optimize,initialization,ploting,save_output)
% This function runs a MLE/MAP estimation of the Macro Model

disp('************************************************');
disp('START of Step 1: Estimation of the Macro Model');
disp('************************************************');
disp('->');

%% Prior
prior_shape=20; % shape inverse gamma distribution (the higher, the more informative)

%% Data extraction
% Extract NS factors
%[temp1,~,~] = xlsread('results.xls','Real factors'); % PC
temp1=readmatrix('results.xls','Sheet','Real factors','Range','A2:D361'); % MAC
real_factors=temp1(49:end,2:end); % Start in February 1994 for t (macro data that start in 1994:Q1 for t-1)
[factors_star_HP,~]=hpfilter(real_factors(4:end,:),14400); % L*,S*,C* starting values for the Kalman Filter
dates_M=temp1(52:end,1); % Because L(t,1)/L(t,2)/L(t,3) <=> June-1994/May-1994/April-1994 (so that L(t-1,1)/L(t-1,2)/L(t-1,3) <=> March-1994/February-1994/January-1994) )

% Extract dates and yields maturity (same for nominal and real)
% [temp,~,~] = xlsread('data.xls','real_yields'); % PC
temp=readmatrix('data.xls','Sheet','real_yields','Range','B1:K361'); % MAC
%Nyields=temp(50:end,1:end); % MAC
Nyields=temp(50:end,2:end); % PC
N=size(Nyields,2);
maturities=temp(1,1:end)'; % MAC
%maturities=temp(1,2:end)'; % PC
nmax=max(maturities);

% Extract macro data
% [temp,names_macro,~] = xlsread('data.xls','data_MODEL','A1:Y105'); % PC
% data_Q=temp(2:end,1); % PC
% names_macro=names_macro(1,2:end)'; % PC
% temp=temp(1:end,2:end); % PC
temp=readcell('data.xls','Sheet','data_MODEL','Range','A1:Y105'); % MAC
names_macro=temp(1,2:end);
dates_Q=cell2mat(temp(3:end,1)); % You want to skip the 1st quarter as it will be t=t-1
temp=cell2mat(temp(2:end,2:end));

% Pick the right endogeneous variables for the MODEL. Names must be as in the data spreadsheet
names_data_endo={'REER';'Financial';'OB';'RealGDP';'Inflation';'Cap'};

% data_endo
for i=1:size(names_data_endo,1)
    for j=find(strcmp(names_macro,names_data_endo(i))==1) % In case the order if variables has been moved in the data spreadsheet
        data_endo(:,i)=temp(:,j);
    end
end
    
% Pick the right exogeneous variables for the MODEL. Names must be as in the data spreadsheet
names_data_exo={'Policy rate';'M3 growth';'MOF';'GovSpending';'RealCredit%GDP';'TOT';...
                    'Openness';'ULC';'TotalPurchase%GDP';'HHdebt';'NFCdebt';'VIX';'Taxes';'DebtService';...
                    'Dependency';'USPPIInflation';'WageInflation';'EnergyInflation'};

% data_exo
for i=1:size(names_data_exo,1)
    for j=find(strcmp(names_macro,names_data_exo(i))==1) % In case the order if variables has been moved in the data spreadsheet
        data_exo(:,i)=temp(:,j);
    end
end

% Starting values for the Kalman Filter
g=data_endo(2:end,4)-data_endo(1:end-1,4);
[macro_star_HP,~]=hpfilter([data_endo(2:end,1:4),g,data_endo(2:end,6)],1600); % REER*,Fin*,Ob*,y*,g*,cap*

%[lambda,~,~] = xlsread('parameters','NS','C32'); % PC
lambda=readmatrix('parameters.xls','Sheet','NS','Range','C32:C32'); % MAC

%% Parameters starting values
% Prior tightness and variance
%[prior_hyper,~,~] = xlsread('parameters','MODEL','C4:C94'); % PC
prior_hyper=readmatrix('parameters.xls','Sheet','MODEL','Range','C4:C94'); % MAC
if initialization==0
    %[Psi0,~,~] = xlsread('parameters','MODEL','D4:D94'); % PC
    Psi0=readmatrix('parameters.xls','Sheet','MODEL','Range','D4:D94'); % MAC
    prior_beliefs=Psi0;
elseif initialization==1
    disp('Finding initial values for the parameters...')
    Psi0=init_val_MODEL(lambda,real_factors(4:end,:),factors_star_HP,macro_star_HP,data_endo(2:end,:),data_exo(2:end,:));
    prior_beliefs=Psi0;
    ENERGY=KF_MODEL(Psi0,lambda,real_factors,factors_star_HP,macro_star_HP,data_endo,data_exo,prior_hyper,prior_shape,prior_beliefs,0,0);
    Y_OLS=KF_MODEL(Psi0,lambda,real_factors,factors_star_HP,macro_star_HP,data_endo,data_exo,prior_hyper,prior_shape,prior_beliefs,0,1);
    RMSE_OLS=Y_OLS(end,end);
    %xlswrite('parameters',[RMSE_OLS;-ENERGY;Psi0],'MODEL','B2:B94'); % PC
    writematrix([RMSE_OLS;-ENERGY;Psi0],'parameters.xls','Sheet','MODEL','Range','B2:B94'); % MAC
end

%% Estimation
if optimize~=0 % Start MLE/MAP estimation
    if optimize==1
        disp('Starting ML estimation');
    else
        disp('Starting MAP estimation');
    end    
     % Constraints on coefficients
    [lb,ub]=restrictions(Psi0,'MODEL');
    startTic=tic;
    epsilon = 1e3;
    while epsilon > 1e-5
        Psi=fmincon(@(Psi)KF_MODEL(Psi,lambda,real_factors,factors_star_HP,macro_star_HP,data_endo,data_exo,prior_hyper,prior_shape,prior_beliefs,optimize,0),Psi0,[],[],[],[],lb,ub,[],options1);        
        epsilon = abs(Psi-Psi0);
        epsilon = max(epsilon);
        Psi0=Psi;
    end
    [Psi0,ENERGY,~,~,Gradient,Hessian]=fminunc(@(Psi)KF_MODEL(Psi,lambda,real_factors,factors_star_HP,macro_star_HP,data_endo,data_exo,prior_hyper,prior_shape,prior_beliefs,optimize,0),Psi0,options2);
    time_elapsed=toc(startTic);
    disp('Optimization done');
    disp('Time needed in seconds for optimization is');
    disp(time_elapsed)
    disp('Energy value for Macro Model is');
    disp(ENERGY);
    disp('(Penalized) likelihood value for Macro Model is');
    disp(-ENERGY); 

    % Compute Standard Errors
    [ste,robust_ste,robust_z_ratio,z_ratio,pvalues,robust_pvalues]=standard_error(Psi0,Gradient,Hessian);

end

%% Extract results
% Compute results with optimized parameters
disp('Computation of final results');
Y=KF_MODEL(Psi0,lambda,real_factors,factors_star_HP,macro_star_HP,data_endo,data_exo,prior_hyper,prior_shape,prior_beliefs,optimize,1);

% Natural NS factors
L_star=NaN(size(dates_M,1),1);
S_star=NaN(size(dates_M,1),1);
C_star=NaN(size(dates_M,1),1);  
i=1;
for t=1:size(dates_Q,1)
    L_star(i:i+2,1)=[Y(t,3);Y(t,2);Y(t,1)];
    S_star(i:i+2,1)=[Y(t,6);Y(t,5);Y(t,4)];
    C_star(i:i+2,1)=[Y(t,9);Y(t,8);Y(t,7)];
    i=i+3;
end

% Potential variables
REER_star=Y(:,10);
Fin_star=Y(:,11);
Ob_star=Y(:,12);
y_star=Y(:,13);
g_star=Y(:,14);
cap_star=Y(:,15);

% Recover natural yield curves
[Natural_yields_all,Natural_yields,~]=NS_pricing(lambda,size(L_star,1),N,maturities,[L_star,S_star,C_star]);

% Recover L,S,C,r*,L*,S*,C* on a quarterly basis
real_factors=real_factors(4:end,:);
real_r=Ryields(52:end,1);
r_star=Natural_yields(:,1);
real_r_Q=NaN(size(dates_Q,1),1);
r_star_Q=NaN(size(dates_Q,1),1);
L_star_Q=NaN(size(dates_Q,1),1);
S_star_Q=NaN(size(dates_Q,1),1);
C_star_Q=NaN(size(dates_Q,1),1);
real_factors_Q=NaN(size(dates_Q,1),3);
j=1;
for i=1:3:size(dates_M,1)
    real_factors_Q(j,:)=mean(real_factors(i:i+2,:),1);
    real_r_Q(j,1)=mean(real_r(i:i+2,1));
    r_star_Q(j,1)=mean(r_star(i:i+2,1));
    L_star_Q(j,:)=mean(L_star(i:i+2,:),1);
    S_star_Q(j,:)=mean(S_star(i:i+2,:),1);
    C_star_Q(j,:)=mean(C_star(i:i+2,:),1);
    j=j+1;
end
natural_factors_Q=[L_star_Q,S_star_Q,C_star_Q];

% Display RMSE
RMSE=Y(end,end);
disp('RMSE for Macro Model is');
disp(RMSE);

%% Debt dynamics
% Pre-allocate
loading=NaN(N,3);
% Loop over each maturity
for n=1:N % Not working if 20-year bond is included
   loading(n,1)=1; % Level
   loading(n,2)=(1-exp(-n/lambda))/(n/lambda); % Slope
   loading(n,3)=((1-exp(-n/lambda))/(n/lambda))-exp(-n/lambda); % Curvature
end
for i=1:3 % Be careful if 20-year bond is included
    MU_prime(i)=(1/N)*sum(loading(1:N,i),1);
end

% Real weighted yield curve
real_yield_curve_Q=repmat(MU_prime(1),size(real_factors_Q,1),1).*real_factors_Q(:,1);
real_yield_curve_Q=real_yield_curve_Q+repmat(MU_prime(2),size(real_factors_Q,1),1).*real_factors_Q(:,2);
real_yield_curve_Q=real_yield_curve_Q+repmat(MU_prime(3),size(real_factors_Q,1),1).*real_factors_Q(:,3);

% Natural weighted yield curve
natural_yield_curve_Q=repmat(MU_prime(1),size(natural_factors_Q,1),1).*natural_factors_Q(:,1);
natural_yield_curve_Q=natural_yield_curve_Q+repmat(MU_prime(2),size(natural_factors_Q,1),1).*natural_factors_Q(:,2);
natural_yield_curve_Q=natural_yield_curve_Q+repmat(MU_prime(3),size(natural_factors_Q,1),1).*natural_factors_Q(:,3);

% Weighted yield curve gap
yield_curve_gap_Q=real_yield_curve_Q-natural_yield_curve_Q;

% Short-term interest rate gap
r_gap_Q=real_r_Q-r_star_Q;

% Snowball effect
debt_coefficient=natural_yield_curve_Q-g_star;

%% Re-write the optimized parameters on Excel
if optimize==1 || optimize==2
    %xlswrite('parameters',[RMSE;-ENERGY;Psi0],'MODEL','D2:D94'); % PC
    %xlswrite('parameters',[ste,z_ratio,pvalues],'MODEL','E4:G94'); % PC
    %xlswrite('results',[dates_M,L_star,S_star,C_star],'Natural factors','A2'); % PC
    %xlswrite('results',[dates_Q,y_star,g_star,cap_star],'Potential variables','A2'); % PC
    %xlswrite('results',[r_star_Q,real_yield_curve_Q,natural_yield_curve_Q,yield_curve_gap_Q],'r and r_star','C2'); % PC
    %xlswrite('results',[dates_M,Ryields(52:end,:)],'Real yields','A2'); % PC
    %xlswrite('results',[dates_M,Natural_yields],'Natural yields','A2'); % PC
    writematrix([RMSE;-ENERGY;Psi0],'parameters.xls','Sheet','MODEL','Range','D2:D94'); % MAC
    writematrix([ste,z_ratio,pvalues],'parameters.xls','Sheet','MODEL','Range','E4:G94'); % MAC
    writematrix([dates_M,L_star,S_star,C_star],'results.xls','Sheet','Natural factors','Range','A2'); % MAC    
    writematrix([dates_Q,REER_star,Fin_star,Ob_star,y_star,g_star,cap_star],'results.xls','Sheet','Potential variables','Range','A2'); % MAC
    writematrix([r_star_Q,real_yield_curve_Q,natural_yield_curve_Q,yield_curve_gap_Q],'results.xls','Sheet','r and r_star','Range','C2'); % MAC  
    writematrix([dates_M,Ryields(52:end,:)],'results.xls','Sheet','Real yields','Range','A2'); % MAC
    writematrix([dates_M,Natural_yields],'results.xls','Sheet','Natural yields','Range','A2'); % MAC
    disp('Parameters saved');
    disp('Results saved');
else
    disp('Parameters and results not saved');
end

disp('->');
disp('**********************************************');
disp('END of Step 1: Estimation of the Macro Model');
disp('**********************************************');

clear data names epsilon optimize

%% Plot results
if ploting==1
    % Different monetary regimes
    regimes(1,:)=[dates_M(1,1),1999.08]; % Pre-regimes
    regimes(2,:)=[1999.17,2000.50]; % ZIRP
    regimes(3,:)=[2001.25,2006.17]; % QE
    regimes(4,:)=[2010.83,2013.25]; % CME
    regimes(5,:)=[2013.33,2016]; % QQE
    regimes(6,:)=[2016.75,2020]; % QQE with yield curve control
    regimes_names={'Pre-regimes';'ZIRP';'QE';'CME';'QQE';'QQE with yield curve control'};

    graphs(dates_M,[1:1:nmax]',N,Natural_yields_all,'Natural yield surface',7,1,save_output) % Plot natural yield surface
    j=0;
    for i=regimes(:,1)'
        j=j+1;
        starting=find(dates_M(:,1)==i);
        end_date=regimes(j,2);
        ending=find(dates_M(:,1)==end_date);
       graphs(dates_M(starting:ending,1),maturities,N,Natural_yields(starting:ending,:),char(strcat('Natural yield curves quartiles',' (',regimes_names(j),')')),4,1,save_output) % Plot Quartiles of natural yield curve
       graphs(dates_M(starting:ending,1),maturities,N,[Ryields(starting:ending,:),Natural_yields(starting:ending,:)],char(strcat('Real v.s Natural yield curves',' (',regimes_names(j),')')),5,1,save_output) % Plot nominal v.s natural yield curve
    end
    graphs(dates_M,[],N,[L_star,S_star,C_star],'Natural NS Factors',6,1,save_output) % Plot natural Level, Slope, Curvature
    graphs(dates_M,[],[],[real_factors(:,1),L_star],'Level gap',3,1,save_output) % Plot Level gap
    graphs(dates_M,[],[],[real_factors(:,2),S_star],'Slope gap',3,1,save_output) % Plot Slope gap
    graphs(dates_M,[],[],[real_factors(:,3),C_star],'Curvature gap',3,1,save_output) % Plot Curvature gap
    
    % Potential variables
    graphs(dates_Q,[],[],[data_endo(2:end,1),macro_star_HP(:,1),REER_star],'Potential REER',1,2,save_output) % Plot REER*
    graphs(dates_Q,[],[],[data_endo(2:end,2),macro_star_HP(:,2),Fin_star],'Potential Financial',2,2,save_output) % Plot Fin*
    graphs(dates_Q,[],[],[data_endo(2:end,3),macro_star_HP(:,3),Ob_star],'Potential Overall Balance',3,2,save_output) % Plot Ob*
    graphs(dates_Q,[],[],[data_endo(2:end,4),macro_star_HP(:,4),y_star],'Potential Output',4,2,save_output) % Plot y*
    graphs(dates_Q,[],[],[100*g,100*macro_star_HP(:,5),100*g_star],'Potential output growth',5,2,save_output) % Plot g*
    graphs(dates_Q,[],[],[data_endo(2:end,6),macro_star_HP(:,6),cap_star],'Potential Capacity Utilization',6,2,save_output) % Plot cap*

    graphs(dates_Q,[],[],[r_gap_Q,(data_endo(2:end,1)-REER_star)/100],'REER gap',7,2,save_output) % Plot interest rate gap and REER gap
    graphs(dates_Q,[],[],[yield_curve_gap_Q,(data_endo(2:end,1)-REER_star)/100],'REER gap',8,2,save_output) % Plot yield curve gap and REER gap
    
    graphs(dates_Q,[],[],[r_gap_Q,(data_endo(2:end,2)-Fin_star)/100],'Financial gap',7,2,save_output) % Plot interest rate gap and financial cycle gap
    graphs(dates_Q,[],[],[yield_curve_gap_Q,(data_endo(2:end,2)-Fin_star)/100],'Financial gap',8,2,save_output) % Plot yield curve gap and financial cycle gap

    graphs(dates_Q,[],[],[r_gap_Q,(data_endo(2:end,3)-Ob_star)],'Overall Balance gap',7,2,save_output) % Plot interest rate gap and OB gap
    graphs(dates_Q,[],[],[yield_curve_gap_Q,(data_endo(2:end,3)-Ob_star)],'Overall Balance gap',8,2,save_output) % Plot yield curve gap and OB gap

    graphs(dates_Q,[],[],[r_gap_Q,100*(data_endo(2:end,4)-y_star)],'Output gap',7,2,save_output) % Plot interest rate gap and Output gap
    graphs(dates_Q,[],[],[yield_curve_gap_Q,100*(data_endo(2:end,4)-y_star)],'Output gap',8,2,save_output) % Plot yield curve gap and Output gap

    graphs(dates_Q,[],[],[r_gap_Q,100*g_star],'Potential output growth',7,2,save_output) % Plot interest rate gap and Potential Output growth
    graphs(dates_Q,[],[],[yield_curve_gap_Q,100*g_star],'Potential output growth',8,2,save_output) % Plot yield curve gap and Potential Output growth

    graphs(dates_Q,[],[],[r_gap_Q,data_endo(2:end,5)],'Inflation',7,2,save_output) % Plot interest rate gap and inflation
    graphs(dates_Q,[],[],[yield_curve_gap_Q,data_endo(2:end,5)],'Inflation',8,2,save_output) % Plot yield curve gap and inflation

    graphs(dates_Q,[],[],[r_gap_Q,(data_endo(2:end,6)-cap_star)/100],'Capacity Utilization gap',7,2,save_output) % Plot interest rate gap and cap gap
    graphs(dates_Q,[],[],[yield_curve_gap_Q,(data_endo(2:end,6)-cap_star)/100],'Capacity Utilization gap',8,2,save_output) % Plot yield curve gap and cap gap
    
    graphs(dates_Q,[],[],[r_gap_Q,yield_curve_gap_Q],'Yield curve gap',10,2,save_output) % Plot interest rate gap vs yield curve gap

    graphs(dates_Q,[],[],debt_coefficient,'Snowball effect',9,2,save_output) % Plot the snowball effect

end