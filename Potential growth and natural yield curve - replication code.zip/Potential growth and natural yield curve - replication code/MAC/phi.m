function MU=phi(mu,lambda,N) 
% Compute NS loadings

% Pre-allocate
loading=NaN(N,3);
MU=NaN(3,1);

% Loop over each maturity
for n=1:N
   loading(n,1)=1; % Level
   loading(n,2)=(1-exp(-n/lambda))/(n/lambda); % Slope
   loading(n,3)=((1-exp(-n/lambda))/(n/lambda))-exp(-n/lambda); % Curvature
end

% Compute mu_L, mu_S, mu_C
for i=1:3
    MU(i,1)=mu*(1/N)*sum(loading(1:N,i),1);
end

end