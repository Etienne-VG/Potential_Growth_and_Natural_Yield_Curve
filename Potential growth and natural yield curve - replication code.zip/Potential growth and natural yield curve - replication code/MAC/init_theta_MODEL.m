function Y=init_theta_MODEL(Zeta,lambda,jmax,N,LHS,RHS,index)
% This functions runs an MLE to find initial values for MIDAS model

% Retreive parameters
omega_y=Zeta(1);
Phi_y=Zeta(2);
mu=Zeta(3);
thetaV=Zeta(4:9);
Phi_yOB=Zeta(10);
delta_y=Zeta(11);

% Build bL/bS/bC
theta(1,1)=thetaV(1);
theta(1,2)=thetaV(2);
theta(2,1)=thetaV(3);
theta(2,2)=thetaV(4);
theta(3,1)=thetaV(5);
theta(3,2)=thetaV(6);
b=ALMOND(theta,jmax,3); % Compute exponential ALMOND lags
MU=phi(mu,lambda,N); % Compute mu_L, mu_S, mu_C (and mu_C2)

% Pre-allocate
energy=NaN(size(RHS,1),1);
y_gap_t=NaN(size(RHS,1),1);
erreur=NaN(size(RHS,1),1);
ERROR=0;

% Loop for MLE
for t =1:size(RHS,1)
        
    % Equation 27
    y_gap_t(t)=omega_y+Phi_y*RHS(t,1)... % y-y*
               +MU(1)*(b(1,1)*RHS(t,2)+b(1,2)*RHS(t,3)+b(1,3)*RHS(t,4))... L-L*
               +MU(2)*(b(2,1)*RHS(t,5)+b(2,2)*RHS(t,6)+b(2,3)*RHS(t,7))... S-S*
               +MU(3)*(b(3,1)*RHS(t,8)+b(3,2)*RHS(t,9)+b(3,3)*RHS(t,10))... C-C*
               +Phi_yOB*RHS(t,11); % Ob-Ob*
    
    erreur(t) = LHS(t) - y_gap_t(t);
    energy(t) = 1/2*(log(2*pi)+log(delta_y) + (1/delta_y)*(erreur(t)^2));
    ERROR=ERROR+erreur(t).^2;
    
end

% Energy
ENERGY = sum(energy);

% RMSE
RMSE=sum(ERROR);
RMSE=sqrt(RMSE/size(LHS,1));

if index==0
    Y=RMSE;
elseif index==1
    Y=ENERGY;
else    
    Y=erreur;
end