function Y = KF_NS(Omega,maturities,yields,X0,prior_hyper,prior_shape,prior_beliefs,optimize,index)
% This function runs the Kalman filter for the Dynamic Nelson-Siegel model

% Declare some constants
T = size(yields,1);
N=size(yields,2);
nstate=3;

% Step 0: Set up
[mu,Theta,Sigma_zeta,Sigma_epsilon,lambda,Omega1,Omega2,Omega3,Omega4]=Setup_KF_NS(Omega,N);

% Build LAMBDA
LAMBDA=NaN(N,nstate);
for n=maturities'
   j=find(maturities==n);
   LAMBDA(j,1)=1;
   LAMBDA(j,2)=(1-exp(-n/lambda))/(n/lambda);
   LAMBDA(j,3)=(1-exp(-n/lambda))/(n/lambda)-exp(-n/lambda);   
end
    
% Kalman Filter %

% Preallocation
Xt_1 = NaN(nstate,T+1);
Xt = NaN(nstate,T+1);
Pt_1 = NaN(nstate,nstate,T+1);
Pt = NaN(nstate,nstate,T+1);
energy = NaN(1,T);
ERROR=zeros(N,1);

% Step 1: Initialization
Xt(:,1)=(Theta\eye(size(Theta,1)))*X0(1,:)'-mu;
Pt(:,:,1)=eye(nstate);

% Step 2: Prediction
for t = 1:1:T
    Xt_1(:,t) = mu+Theta*Xt(:,t); % State equation
    Pt_1(:,:,t) = Theta*Pt(:,:,t)*Theta' + Sigma_zeta; % Variance state equation
    Y_hat=LAMBDA*Xt_1(:,t); % Measurement equation
    F = LAMBDA*Pt_1(:,:,t)*LAMBDA' + Sigma_epsilon; % Variance measurement equation
    erreur = yields(t,:)' - Y_hat;
    
    % Check if F is not inversible (wrong initial values for the parameters), then return
    if rcond(F) < 1e-8
        Y = 10^8;
        return
    end
    flag = det(F);
    if (~(isfinite(flag))) || (~(flag>0))
        Y = 10^9;
        return  
    end
    
    % Step 3: Update
    
    % Cholesky trick because F is usually not invertible
    inv_FxLambda=inverse_F(F,LAMBDA);
    K = Pt_1(:,:,t)*transpose(inv_FxLambda); % Kalman gain as in our paper
    
    %K=Pt_1(:,:,t)*LAMBDA'*(F\eye(size(F,1))); % Old version without Cholesky trick
    
    Xt(:,t+1) = Xt_1(:,t) + K*erreur;
    Pt(:,:,t+1) = Pt_1(:,:,t)-K*F*K';
        
    % Step 5: Calculate the Energy function
    energy(t) = 1/2*(N*log(2*pi)+log(det(F)) + erreur'*(F\eye(size(F,1)))*erreur); 

end

if optimize==2 % MAP
    % Build priors
    [p_Omega1,p_Omega2]=prior_density(Omega1,Omega2,prior_hyper,prior_shape,prior_beliefs,3,'state','NS'); % State Equation
    [p_Omega3,p_Omega4]=prior_density(Omega3,Omega4,prior_hyper,prior_shape,prior_beliefs,N,'measurement','NS'); % Measurement Equation
    priors=p_Omega1*p_Omega2*p_Omega3*p_Omega4;
else    
    priors=1; % MLE
end    
        
ENERGY = sum(energy)-log(priors);

if index==0 % MLE/MAP
    Y = ENERGY;
elseif index==1
    Xf=Xt(:,2:end)';
    % RMSE
    for t=1:1:T
        Y_hat=LAMBDA*Xf(t,:)';
        erreur = yields(t,:)' - Y_hat;
        ERROR=ERROR+(erreur.^2);
    end
    % RMSE
    RMSE=sum(ERROR);
    RMSE=sqrt(RMSE/(N*T));
    Y=[Xf,repmat(RMSE,T,1)];
end

end