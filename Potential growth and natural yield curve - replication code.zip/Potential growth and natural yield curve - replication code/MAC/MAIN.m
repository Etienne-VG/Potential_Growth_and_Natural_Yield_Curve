%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% POTENTIAL GROWTH AND NATURAL YIELD CURVE IN JAPAN %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Published in Journal of International Money and Finance %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Gilles Dufrenot, Meryem Rhouzlane & Etienne Vaccaro-Grange %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Correspondance for the code: etienne.vaccaro-grange@nyu.edu %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc; close all;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script runs all the codes at once:
% Step 0: Extract real yields
% Step 1: ML/MAP estimation of Nelson-Siegel latent factors (Step 1)
% Step 2: ML/MAP estimation of the Macro model (Step 2)

% /!\ DATES /!\ 
% Yields should start in 1990:M01 and end in December 2019:M12 (NS input)
% Real factors will range from 1990:M01 to 2019:M12 (first date used is 1994:M01) (NS output)
% Macro time series should start in 1994:Q1 and end in 2019:Q4 (MODEL input)
% L*, S*, and C* will range from 1994:M04 to 2019:M12 (MODEL output)
% REER*, Financial*, Ob*, y*, g*, and cap* will range from 1994:Q2 to 2019:Q4 (MODEL output)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% NELSON-SIEGEL MODEL (STEP 1)
optimize_NS=0; % optimize=2 to run MAP estimation, 1 to run ML estimation, 0 otherwise
initialization_NS=0; % To reset parameters to pre-estimated initial values, 1 to reset, 0 otherwise
ploting_NS=1; % ploting=1 to plot results, 0 otherwise
save_output_NS=0; % Save graph in the "Results" folder (/!\ Replaces previous results /!\), 0 otherwise

% MACRO MODEL (STEP 2)
optimize_MODEL=0; % optimize=2 to run MAP estimation, 1 to run ML estimation, 0 otherwise
initialization_MODEL=0; % To reset parameters to pre-estimated initial values uning OLS regressions, 1 to reset, 0 otherwise
ploting_MODEL=1; % ploting=1 to plot results, 0 otherwise
save_output_MODEL=0; % Save graph in the "Results" folder (/!\ Replaces previous results /!\), 0 otherwise

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Options for the maximization of the Log-Likelihood functions
options_NS=optionsetting(10e-6,10e-6,10e3,'fmincon','sqp','on','iter','optimplotfval'); % optionsetting(Tolfun,TolX,Maxfunevals,funct,diag,algo,progress) algo is 'interior-point' (default) or 'sqp'
options_MODEL1=optionsetting(10e-6,10e-6,10e3,'fmincon','interior-point','on','iter','optimplotfval'); % optionsetting(Tolfun,TolX,Maxfunevals,funct,diag,algo,progress) algo is 'interior-point' (default) or 'sqp'
options_MODEL2=optionsetting(10e-2,10e-2,10,'fminunc','interior-point','on','iter','optimplotfval'); % optionsetting(Tolfun,TolX,Maxfunevals,funct,diag,algo,progress) algo is 'interior-point' (default) or 'sqp'

% Step 0: Extract yields
RYields=extract_yields;

% Step 1: Compute Nelson-Siegel latent factors
% Run MLE/MAP
MLE_NS(RYields,options_NS,optimize_NS,initialization_NS,ploting_NS,save_output_NS);

% Step 2: Macro model
% Run MLE/MAP
MLE_MODEL(RYields,options_MODEL1,options_MODEL2,optimize_MODEL,initialization_MODEL,ploting_MODEL,save_output_MODEL);

disp('Code has run successfully');
