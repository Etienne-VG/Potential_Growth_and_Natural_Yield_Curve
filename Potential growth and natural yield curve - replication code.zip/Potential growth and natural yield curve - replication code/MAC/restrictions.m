function [lb,ub]=restrictions(Omega,model)

% indexes to change if parameters order is changed
% lb(i)=0 forces the parameter to be POSITIVE
% ub(i)=0 forces the parameter to be NEGATIVE

lb=-Inf(1,size(Omega,1));
ub=Inf(1,size(Omega,1));

if strcmp(model,'NS')==1 % Nelson-Siegel

    lb(13)=0; % sigma_zeta11 positive
    lb(16)=0; % sigma_zeta22 positive
    lb(18)=0; % sigma_zeta33 positive
    lb(19:28)=zeros(1,10);  % sigma_epsilonii positive
    
elseif strcmp(model,'INIT')==1 % Initial values for MODEL
    
    ub(3)=0; % mu negative
    ub(10)=0; % Phi_yOb negative
    
elseif strcmp(model,'MODEL')==1 % MODEL
    
    lb(83:91)=zeros(1,9); % Omega_1 positive
    lb(74:82)=zeros(1,9); % Omega_2 positive

    ub(28)=0; % phi_yOB negative
    lb(31)=0; % phi_picap positive
    lb(32)=0; % phi_capy positive
    ub(34)=0; % mu negative

end    
end