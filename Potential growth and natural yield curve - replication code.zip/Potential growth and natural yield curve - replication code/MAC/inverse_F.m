function X = inverse_F(F,H)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function enables to solve for the inverse of matrix F without inversing it directly
% See "Kalman Filter, Theory and Practice Using Matlab" (Grewal & Andrews) Section 6.4.3.4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% UD Decomposition
[U,D]=UD_decomp(F);

% Solve for X_1: U*X_1=H
X_1=chol_solve(U,D,H,[],1);

% Solve for X_2: D*X_2=X_1
X_2=chol_solve(U,D,H,X_1,2);

% Solve for X: U'*X=X_2
X=chol_solve(U,D,H,X_2,3);

end
