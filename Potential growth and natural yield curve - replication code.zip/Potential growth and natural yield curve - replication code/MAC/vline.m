function hhh=vline(x1,x2,in1,in2)

linetype=in1;
label=in2;
    
g=ishold(gca);
hold on

y=get(gca,'ylim');

if x2~=0;
    
    h1=plot([x1 x1],y,linetype,'LineWidth',1.5);
    h2=plot([x2 x2],y,linetype,'LineWidth',1.5);
    if  strcmp(in2,'ZIRP')==1
        text((x1+x2)/2-0.44*(x2-x1),y(2),label,'color',get(h1,'color'),'FontSize',18);
    elseif strcmp(in2,'QE')==1
        text((x1+x2)/2-0.09*(x2-x1),y(2),label,'color',get(h1,'color'),'FontSize',18);
    elseif strcmp(in2,'CME')==1 || strcmp(in2,'QQE')==1
        text((x1+x2)/2-0.25*(x2-x1),y(2),label,'color',get(h1,'color'),'FontSize',18);
    else
        text((x1+x2)/2,y(2)-0.5,label,'color',get(h1,'color'),'FontSize',18);
    end
    
    if g==0
    hold off
    end
    set(h1,'tag','vline','handlevisibility','off')
    set(h2,'tag','vline','handlevisibility','off')

else
    h1=plot([x1 x1],y,linetype,'LineWidth',1.5);
    text(x1+0.25,y(2),label,'color',get(h1,'color'),'FontSize',18)
    
    if g==0
    hold off
    end
    set(h1,'tag','vline','handlevisibility','off')
end


end