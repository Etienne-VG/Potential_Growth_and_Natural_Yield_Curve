function [all_yields,selected_yields,LAMBDA_selected]=NS_pricing(lambda,T,N,maturities,Xt)

% Recover natural yield curves
all_yields=NaN(T,max(maturities));
LAMBDA_all=NaN(max(maturities),3);
for n=1:max(maturities)
    LAMBDA_all(n,1)=1;
    LAMBDA_all(n,2)=(1-exp(-n/lambda))/(n/lambda);
    LAMBDA_all(n,3)=(1-exp(-n/lambda))/(n/lambda)-exp(-n/lambda);
    all_yields(:,n)=Xt(:,1)*LAMBDA_all(n,1)'+Xt(:,2)*LAMBDA_all(n,2)'+Xt(:,3)*LAMBDA_all(n,3)';
end

% Only selected maturities
selected_yields=NaN(T,N);
LAMBDA_selected=NaN(N,3);
for n=maturities'
    j=find(maturities==n);
    selected_yields(:,j)=all_yields(:,n);
    LAMBDA_selected(j,:)=LAMBDA_all(n,:);
end

end
