function [ste,robust_ste,robust_z_ratio,z_ratio,pvalues,robust_pvalues]=standard_error(Parameters,Gradient,Hessian)

% Standard errors
ste=real(sqrt(diag(Hessian\eye(size(Hessian,1))))); % Should be -Hessian if fminunc optimizes the Log-Likelihood and not -Log-Likelihood

% Robust Standard errors (maximum likelihood analogue of White's consistent standard errors)
robust_ste=real(sqrt(diag((Hessian\eye(size(Hessian,1)))*Gradient*transpose(Gradient)*(Hessian\eye(size(Hessian,1)))))); % Should be -Hessian if fminunc optimizes the Log-Likelihood and not -Log-Likelihood

% Z-ratios:
z_ratio=Parameters./ste;
robust_z_ratio=Parameters./robust_ste;

% P-values
pvalues=2*normcdf(-(abs(z_ratio)));
robust_pvalues=2*normcdf(-(abs(robust_z_ratio)));

end