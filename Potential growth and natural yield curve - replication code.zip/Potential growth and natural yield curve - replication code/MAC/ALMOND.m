function b=ALMOND(theta,jmax,nstate)

% i is L,S or C so i=1:3
% j=1:jmax
% theta is 3 line and 2 column

% Compute numerator of b_L, b_S, b_C
poly=NaN(nstate,jmax);
for j=1:jmax
    for i=1:nstate
        poly(i,j)=exp(theta(i,1)*j+theta(i,2)*j^2);
    end    
end   

% Compute b_L, b_S, b_C
b=NaN(nstate,jmax);
for i=1:nstate
    for j=1:jmax
        b(i,j)=poly(i,j)/(sum(poly(i,:),2));
    end    
end 

end