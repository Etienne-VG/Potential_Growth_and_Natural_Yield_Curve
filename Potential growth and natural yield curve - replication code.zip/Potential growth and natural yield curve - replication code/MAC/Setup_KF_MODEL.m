function [A,Omega_1,C,E,D,G,B,Omega_2,Y_t,Y_tmoins1,Z_tmoins1,Psi1,Psi2,Psi3,Psi4]=Setup_KF_MODEL(Psi,lambda,real_factors,data_endo,data_exo,T_q)
% This function builds the matrices necessary for the Kalman Filter of the Macro model

% Define the number of state variables according to the model
nendo=size(data_endo,2); % number of endogeneous (macro) variables
nstate=3;
jmax=3;
N=10;

% Build A (15x15), feedback matrix in state equation
A1=repmat(Psi(66),3,3); % beta_L*
A2=repmat(Psi(67),3,3); % beta_S*
A3=repmat(Psi(68),3,3); % beta_C*
A4=Psi(69); % beta_REER*
A5=Psi(70); % beta_Fin*
A6=Psi(71); % beta_Ob*
A7=Psi(72); % beta_g*
A8=Psi(73); % beta_cap*
A=blkdiag(A1,A2,A3,A4,A5,A6,1,A7,A8);
A(13,14)=1; % g*_{t-1}

% Build Omega_1 (15x15), variance-covariance matrix state equation    
Omega_1=blkdiag(Psi(83),Psi(83),Psi(83),Psi(84),Psi(84),Psi(84),Psi(85),Psi(85),Psi(85),Psi(86),Psi(87),Psi(88),Psi(89),Psi(90),Psi(91)); % delta_L*, delta_S*, delta_C*, delta_REER*, delta_Fin*, delta_Ob* , delta_y*, delta_g*, delta_cap*
% Build C (15x1), constant measurement equation
C=[Psi(1);Psi(1);Psi(1);Psi(2);Psi(2);Psi(2);Psi(3);Psi(3);Psi(3);Psi(4:9)]; % omega_L, omega_S, omega_C, omega_REER, omega_Fin, omega_Ob, omega_y, omega_pi, omega_cap

% Build E (15x15), measurement equation 
E=[eye(13),zeros(13,2);zeros(1,15);zeros(1,14),1];

% Thetas
mu=Psi(34); % mu, assumed to be negative (used in function "phi" below)
k=0;
theta=NaN(3,2);
for i=1:3
    for j=1:2
        k=k+1;
        theta(i,j)=Psi(34+k); % For function "ALMOND" below. Theta1 needs to be positive and theta 2 negative to have a declining function
    end
end
% Compute exponential ALMOND lags
b=ALMOND(theta,jmax,nstate);
% Compute mu_L, mu_S, mu_C
MU=phi(mu,lambda,N);
% bL, bS, bC
for i=1:3
    for j=1:jmax
        b(i,j)=MU(i)*b(i,j);
    end
end

% Build D (15x15), measurement equation 
% L
D1=repmat(Psi(10),3,3); % Phi_L
D2=repmat(Psi(16),3,1); % Phi_LREER
D3=repmat(Psi(17),3,1); % Phi_LFin
D4=repmat(Psi(18),3,1); % Phi_LOb
% S
D5=repmat(Psi(11),3,3); % Phi_S
D6=repmat(Psi(20),3,1); % Phi_SREER
D7=repmat(Psi(21),3,1); % Phi_SFin
D8=repmat(Psi(22),3,1); % Phi_SOb
% C
D9=repmat(Psi(12),3,3); % Phi_C
D10=repmat(Psi(24),3,1); % Phi_CREER
D11=repmat(Psi(25),3,1); % Phi_CFin
D12=repmat(Psi(26),3,1); % Phi_COb

% 1st line of D (L)
DL1=[-D1,zeros(3,3),zeros(3,3),-D2,-D3,-D4,zeros(3,1),zeros(3,1),zeros(3,1)];
% 2nd line of D (S)
DL2=[zeros(3,3),-D5,zeros(3,3),-D6,-D7,-D8,zeros(3,1),zeros(3,1),zeros(3,1)];
% 3rd line of D (C)
DL3=[zeros(3,3),zeros(3,3),-D9,-D10,-D11,-D12,zeros(3,1),zeros(3,1),zeros(3,1)];
% 4th line of D (REER)
DL4=[zeros(1,3),zeros(1,3),zeros(1,3),-Psi(13),0,0,0,0,0];
% 5th line of D (Fin)
DL5=[zeros(1,3),zeros(1,3),zeros(1,3),0,-Psi(14),0,0,0,0];
% 6th line of D (Ob)
DL6=[zeros(1,3),zeros(1,3),zeros(1,3),0,0,-Psi(15),0,0,0];
% 7th line of D (y)
DL7=[-b(1,1),-b(1,2),-b(1,3),-b(2,1),-b(2,2),-b(2,3),-b(3,1),-b(3,2),b(3,3),0,0,-Psi(28),-Psi(29),0,0]; % mu*bL(theta_L1,theta_L2),mu*bL(theta_S1,theta_S2)mu*bL(theta_C1,theta_C2),-Phi_yOb,-Phi_y
% 8th line of D (pi)
DL8=[zeros(1,3),zeros(1,3),zeros(1,3),0,0,0,0,0,-Psi(31)]; % -Phi_{picap}
% 9th line of D (cap)
DL9=[zeros(1,3),zeros(1,3),zeros(1,3),0,0,0,-Psi(32),0,-Psi(33)]; % -Phi_capY, % -Phi_cap

% Assemble D
D=[DL1;DL2;DL3;DL4;DL5;DL6;DL7;DL8;DL9];

% G (15x15), measurement equation 
G=-D;
G(1,14)=Psi(19); % Phi_Lpi
G(2,14)=Psi(23); % Phi_Lpi
G(3,14)=Psi(27); % Phi_Lpi
G(14,14)=Psi(30); % Phi_pi

% Build B (15x18), measurement equation
B=zeros(15,18);
B(1,1:2)=Psi(41:42)'; % alpha_1, alpha_2
B(2,1:2)=Psi(41:42)'; % alpha_1, alpha_2
B(3,1:2)=Psi(41:42)'; % alpha_1, alpha_2
B(4,1:2)=Psi(43:44)'; % beta_1, beta_2
B(5,1:2)=Psi(43:44)'; % beta_1, beta_2
B(6,1:2)=Psi(43:44)'; % beta_1, beta_2
B(7,1:2)=Psi(45:46)'; % gamma_1, gamma_2
B(8,1:2)=Psi(45:46)'; % gamma_1, gamma_2
B(9,1:2)=Psi(45:46)'; % gamma_1, gamma_2
B(10,2:8)=Psi(47:53)'; % kappa_1, kappa_2, kappa_3, kappa_4, kappa_5, kappa_6, kappa_7 
B(11,2)=Psi(54); % xi_1
B(11,9:12)=Psi(55:58)'; % xi_2, xi_3, xi_4, xi_5 
B(12,13:15)=Psi(59:61)'; % psi_1, psi_2, psi_3
B(14,6)=Psi(62); % mu_1
B(14,16:18)=Psi(63:65)'; % mu_2, mu_3, mu_4

% Build Omega_2 (15x15), variance-covariance matrix measurement equation    
Omega_2=blkdiag(Psi(74),Psi(74),Psi(74),Psi(75),Psi(75),Psi(75),Psi(76),Psi(76),Psi(76),Psi(77),Psi(78),Psi(79),Psi(80),Psi(81),Psi(82)); % delta_L, delta_S, delta_C, delta_REER, delta_Fin, delta_Ob, delta_y, delta_pi, delta_cap

% For MAP
Psi1=Psi(66:73); % A State Equation
Psi2=Psi(83:91); % % Omega_1 variances State Equation
Psi3=Psi(1:65); % C, B, and D Measurement Equation
Psi4=Psi(74:82); % Omega_2 Measurement Equation

% Build Y (containing L, S, C, REER, Financial, Ob, y, pi, g)
Y=NaN(T_q+1,nstate*3+nendo);
for t_q=1:T_q+1 % Time index for quarterly data
    g=0;
   for k=1:nstate % For each factors
       for j=1:3 % Each quarter is explained by the last 3 months
           g=g+1;
           Y(t_q,g)=real_factors(t_q*3-j+1,k); % L, S, and C (monthly data)
       end
   end
   Y(t_q,3*nstate+1:15)=data_endo(t_q,:); % REER, Financial, Ob, y, pi, g (quarterly data)
end

% Build Y_{t}: LHS variables measurement equation
Y_t=Y(2:end,:)'; % Y_{t} goes from 1994:Q2 (=April 1994) to 2019:Q4 (=December 2019)
% Build Y_{t-1}: RHS variables measurement equation
Y_tmoins1=Y(1:end-1,:)'; % Y_{t-1} goes from 1994:Q1 (=January 1994) to 2019:Q3 (=September 2019)
% Build Z_{t-1}: exogeneous variables measurement equation
Z_tmoins1=data_exo(1:end-1,:)'; % Z_tmoins1 goes from 1994:Q1 to 2019:Q3

end