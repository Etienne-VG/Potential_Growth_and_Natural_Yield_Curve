function [p_Omega_coeffs,p_Omega_var]=prior_density(Omega1,Omega2,prior_hyper,prior_shape,prior_beliefs,n,equation,model)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function call the sub-function to form the priors (independant Normal-Wishart priors only)

if strcmp(model,'NS')==1 % Nelson-Siegel Step 1
    
    if strcmp(equation,'state')==1 % State Equation
        
        % Retrieve Coefficients
        % AR Coefficients in matrix A
        omega0=prior_beliefs(1:12); % Omega0 from initial values
        % Prior variance of the coefficients
        Sigma0=diag(prior_hyper(1:12)); % Prior tightness
        
        % Variances State Equation
        % Degrees-of-freedom inverse wishart distribution % times 2 to be consistent with inverse gamma
        shape=2*prior_shape;
        
        % scale inverse wishart distribution
        if all(prior_hyper)
            S0=diag([prior_hyper(13);prior_hyper(16);prior_hyper(18)]);
        else             
            % Variance from OLS inititialisation
            S0=zeros(n,n);
            S0(1,1:3)=prior_beliefs(13:15)';
            S0(2,2:3)=prior_beliefs(16:17)';
            S0(3,3)=prior_beliefs(18);
            S0=tril(S0',-1)+S0; % Make matrix symetric
        end
        
        % Form prior densities (Normal & inverse-Wishart)
        % Omega1
        p_Omega_coeffs=form_density_normal(Omega1,omega0,Sigma0);
        
        % Omega2
        p_Omega_var=form_density_wishart(Omega2,S0,shape,n);

    elseif strcmp(equation,'measurement')==1 % Measurement Equation
    
        % Retrieve Coefficients
        % lambda
        omega0=prior_beliefs(end); % Omega0 from initial values
        % Prior variance of the coefficients
        Sigma0=prior_hyper(end); % Prior tightness
        
        % Variances State Equation  
        % shape inverse gamma distribution
        shape=prior_shape;
        % Scale inverse gamma distribution  
        scale=NaN(n,1);
        for i=1:n
            if prior_hyper(18+i)~=0
                scale(i)=prior_hyper(18+i); % Variance from priors
            else             
                scale(i)=prior_beliefs(18+i); % Variance from OLS inititialisation
            end
        end
        
        % Form prior densities (Normal & inverse-Gamma)
        % Omega3
        p_Omega_coeffs=form_density_normal(Omega1,omega0,Sigma0);
        
        % Omega4
        p_Omega_var_temp=NaN(n,1);
        for i=1:n
            p_Omega_var_temp(i)=form_density_gamma(Omega2(i),shape,scale(i));
        end
        p_Omega_var=prod(p_Omega_var_temp);
        
    else
       p_Omega_coeffs=0;
       p_Omega_var=0;
    end
    
elseif strcmp(model,'MODEL')==1 % MODEL Step 2
    
    if strcmp(equation,'state')==1 % State Equation
    
        % Retrieve Coefficients
        % AR Coefficients in matrix A
        omega0=prior_beliefs(66:73); % Psi0 from initial values
        % Prior variance of the coefficients
        Sigma0=diag(prior_hyper(66:73)); % Prior tightness
        
        % Variances State Equation
        % Prior paramaters
        shape=prior_shape; % shape inverse gamma distribution
        scale=NaN(9,1); % scale inverse gamma distribution
        for i=1:9
            if prior_hyper(82+i)~=0
                scale(i)=find_scale(prior_hyper(82+i),shape); % Variance from priors
                %scale(i)=prior_hyper(82+i); % Variance from priors
            else             
                % Variance from OLS inititialisation
                % Psi0 from initial values
                scale(i)=find_scale(prior_beliefs(82+i),shape); % Variance from OLS initialization
                %scale(i)=prior_beliefs(82+i); % Variance from OLS initialization
            end
        end
        
        % Form prior densities (Normal & inverse-Gamma)
        % Psi1
        p_Omega_coeffs=form_density_normal(Omega1,omega0,Sigma0);
        
        % Psi2
        p_Omega_var_temp=NaN(n,1);
        % delta_L*
        p_Omega_var_temp(1)=form_density_gamma(Omega2(1),shape,scale(1));
        p_Omega_var_temp(2)=form_density_gamma(Omega2(1),shape,scale(1));
        p_Omega_var_temp(3)=form_density_gamma(Omega2(1),shape,scale(1));
        % delta_S*
        p_Omega_var_temp(4)=form_density_gamma(Omega2(2),shape,scale(2));
        p_Omega_var_temp(5)=form_density_gamma(Omega2(2),shape,scale(2));
        p_Omega_var_temp(6)=form_density_gamma(Omega2(2),shape,scale(2));
        % delta_C*
        p_Omega_var_temp(7)=form_density_gamma(Omega2(3),shape,scale(3));
        p_Omega_var_temp(8)=form_density_gamma(Omega2(3),shape,scale(3));
        p_Omega_var_temp(9)=form_density_gamma(Omega2(3),shape,scale(3));
        % delta_REER*,delta_Fin*,delta_Ob*,delta_y*,delta_g*,delta_cap*,
        k=4;
        for i=10:n
            p_Omega_var_temp(i)=form_density_gamma(Omega2(k),shape,scale(k));
            k=k+1;
        end
        p_Omega_var=prod(p_Omega_var_temp);
            
    elseif strcmp(equation,'measurement')==1 % Measurement Equation
        
        % Retrieve Coefficients
        % AR Coefficients in matrix C, D, G, and B
        omega0=prior_beliefs(1:65); % Psi0 from initial values
        Sigma0=diag(prior_hyper(1:65)); % Prior tightness
  
        % Variances Measurement Equation
        % Prior paramaters
        shape=prior_shape; % shape inverse gamma distribution
        scale=NaN(9,1); % scale inverse gamma distribution
        for i=1:9
            if prior_hyper(73+i)~=0
                scale(i)=find_scale(prior_hyper(73+i),shape); % Variance from priors
                %scale(i)=prior_hyper(73+i); % Variance from priors
            else             
                % Variance from OLS inititialisation
                % Psi0 from initial values
                scale(i)=find_scale(prior_beliefs(73+i),shape); % Variance from OLS initialization
                %scale(i)=prior_beliefs(73+i); % Variance from OLS initialization
            end
        end
        
        % Form prior densities (Normal & inverse-Whishart)
        % Psi3
        p_Omega_coeffs=form_density_normal(Omega1,omega0,Sigma0);
        
        % Psi4
        p_Omega_var_temp=NaN(n,1);
        % delta_L
        p_Omega_var_temp(1)=form_density_gamma(Omega2(1),shape,scale(1));
        p_Omega_var_temp(2)=form_density_gamma(Omega2(1),shape,scale(1));
        p_Omega_var_temp(3)=form_density_gamma(Omega2(1),shape,scale(1));
        % delta_S
        p_Omega_var_temp(4)=form_density_gamma(Omega2(2),shape,scale(2));
        p_Omega_var_temp(5)=form_density_gamma(Omega2(2),shape,scale(2));
        p_Omega_var_temp(6)=form_density_gamma(Omega2(2),shape,scale(2));
        % delta_C
        p_Omega_var_temp(7)=form_density_gamma(Omega2(3),shape,scale(3));
        p_Omega_var_temp(8)=form_density_gamma(Omega2(3),shape,scale(3));
        p_Omega_var_temp(9)=form_density_gamma(Omega2(3),shape,scale(3));
        % delta_REER,delta_Fin,delta_Ob,delta_y,delta_pi,delta_cap,
        k=4;
        for i=10:n
            p_Omega_var_temp(i)=form_density_gamma(Omega2(k),shape,scale(k));
            k=k+1;
        end
        p_Omega_var=prod(p_Omega_var_temp);
     
    else
        p_Omega_coeffs=0;
        p_Omega_var=0;
    end    
    
else
    p_Omega_coeffs=0;
    p_Omega_var=0;

end    

end