function RYields=extract_yields

% Extract real yields
% [data,~,~] = xlsread('data.xls','real_yields'); % PC
data=readmatrix('data.xls','Sheet','real_yields','Range','A1:K361'); % MAC
RYields=data(2:end,2:end);

end