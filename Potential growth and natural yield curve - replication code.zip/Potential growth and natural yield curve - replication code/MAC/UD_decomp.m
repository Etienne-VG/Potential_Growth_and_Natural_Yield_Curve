function [U,D]=UD_decomp(M)
% Performs modified Cholesky decomposition: M=UDU'
% M is symmetric positive-definite, U is upper triangular and D is diagonal

m=size(M,1);
U=NaN(m,m);
D=NaN(m,m);

for j = m : -1:1,
    for i = j : -1:1,
            sigma = M (i, j);
        for k = j + 1 : m,
            sigma = sigma - U (i, k) *D (k, k) *U (j, k);
        end;
        if i == j
            D (j, j) = sigma;
            U (j, j) = 1;
        else
            U (i, j) = sigma/D (j, j);
        end;
    end;
end;

end