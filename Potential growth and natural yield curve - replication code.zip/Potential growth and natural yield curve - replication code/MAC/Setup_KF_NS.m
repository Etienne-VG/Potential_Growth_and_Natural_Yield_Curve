function [mu,Theta,Sigma_zeta,Sigma_epsilon,lambda,Omega1,Omega2,Omega3,Omega4]=Setup_KF_NS(Omega,N)
% This function builds the matrices necessary for the Kalman Filter of the Dynamic Nelson-Siegel model

% intercept state equation
mu=Omega(1:3);

% feedback matrix state equation
Theta=reshape(Omega(4:12),3,3);

% variance-covariance matrix state equation
Sigma_zeta=zeros(3,3);
Sigma_zeta(1,1:3)=Omega(13:15)';
Sigma_zeta(2,2:3)=Omega(16:17)';
Sigma_zeta(3,3:3)=Omega(18);
Sigma_zeta=tril(Sigma_zeta',-1)+Sigma_zeta; % Make matrix symetric

% variance-covariance measurement equation
Sigma_epsilon=diag(Omega(19:18+N)); % Variances, need to be positive

% scale parameter measurement equation
lambda=Omega(end);

% For Bayesian
Omega1=Omega(1:12);
Omega3=Omega(end);
Omega2=Sigma_zeta;
Omega4=diag(Sigma_epsilon); % Variances, need to be positive


end