function Xj=chol_solve(U,D,H,Xi,index)
% This function enables to solve for X in U*D*U'*X=H

n1=size(H,1);
n2=size(H,2);
Xj=NaN(n1,n2);
X_1=NaN(n1,n2);

switch index
    case 1
    % This case solves for X in U*X_1=H when U is a unit upper triangular matrix.
    % It uses the back substitution technics
        m=size(H,1);
        p=size(H,2);
        Xi;
        
        for j = 1 : p,
            for i = m: -1:1,
                    X_1 (i, j) = H (i, j);
                for k = i + 1 : m,
                    X_1 (i, j) = X_1 (i, j) - U(i, k) *X_1 (k, j);
                end;
            end;
        end;
    Xj=X_1;
    
    case 2
    % This case solves for X in D*X_2=X_1 when D is a diagonal matrix.
    % It is a system of independant scalar equation that have a simple solution
     X_1=Xi;
        m=size(D,1);
        p=size(X_1,2);
        X_2=NaN(m,p);
        
        for i=1:m
            for j=1:p
                X_2(i,j)=X_1(i,j)*(1/D(i,i));
            end    
        end    
     
     Xj=X_2;
    case 3
    % This case solves for X in U'*X=X_2 when U is a unit lower triangular matrix.
    % It uses the forward substitution technics
    X_2=Xi;
    U_prim=U';
    
        m=size(U,1);
        p=size(X_2,2);
        X=NaN(m,p);
        
        for i=1:m
            for j=p:-1:1
                X(i,j)=X_2(i,j);
                for k=1:i-1
                    X(i,j)=X(i,j)-U_prim(i,k)*X(k,j);
                end
            end
        end
    
    Xj=X;
    
end
        
end