function options1=optionsetting(Tolfun,TolX,Maxfunevals,funct,algo,diag,disp,progress)

options1  =  optimset(funct);
options1  =  optimset(options1 , 'TolFun', Tolfun); % Our epsilon in step 6 of the Kalman Filter
options1  =  optimset(options1 , 'TolX',TolX); % minimum variation in Omega after which the solver stops (equivalent to epsilon below)
options1  =  optimset(options1 , 'Algorithm',algo);
options1  =  optimset(options1 , 'Diagnostics',diag);
options1  =  optimset(options1 , 'Display',disp);
options1  =  optimset(options1 , 'LargeScale', 'off'); % 'on' for trust-region algorithm (need to provide gradient) 
options1  =  optimset(options1 , 'MaxFunEvals', Maxfunevals) ; % Maximum number of function evaluations allowed (default is 100*#variables)
options1  =  optimset(options1 , 'FinDiffType', 'forward'); % Finite differences, used to estimate gradients, are either 'forward' (the default), or 'central' (centered). 'central' takes twice as many function evaluations, but should be more accurate.
options1  =  optimset(options1 , 'PlotFcns', progress); % Plot measure of progress
options1=optimset(options1,'UseParallel',true);

end