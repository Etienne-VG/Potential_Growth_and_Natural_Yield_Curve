function Psi0=init_val_MODEL(lambda,real_factors,factors_star,macro_star,data_endo,data_exo)
% This function runs OLS regressions the coefficients of the Macro model

% Declare some constants
nstate=3;
T_q = size(data_exo,1)-1;
N=10;
nendo=size(data_endo,2);
jmax=3;

% Build Y (containing L, S, C, REER, Financial, Ob, y, Pi, cap)
Y=NaN(T_q+1,nstate*3+nendo);
for t_q=1:T_q+1 % Time index for quarterly data
    g=0;
   for k=1:nstate % For each factors
       for j=1:3 % Each quarter is explained by the last 3 months
           g=g+1;
           Y(t_q,g)=real_factors(t_q*3-j+1,k); % L, S, and C (monthly data)
       end
   end
   Y(t_q,3*nstate+1:15)=data_endo(t_q,:); % REER, Financial, Ob, y, Pi, g (quarterly data)
end

% Build Y_{t}: LHS variables measurement equation (one observation shorter than in KF_MODEL (because of g=ln(y^{*HP}_{t}/t^{*HP}_{t-1)}))
Y_t=Y(2:end,:); % Y_{t} goes from 1994:Q3 (=July 1994) to 2019:Q4 (=December 2019)
% Build Y_{t-1}: RHS variables measurement equation
Y_t_moins1=Y(1:end-1,:); % Y_{t-1} goes from 1994:Q2 (=April 1994) to 2019:Q3 (=September 2019)
% Build Z_{t-1}: exogeneous variables measurement equation
Z_t_moins1=data_exo(1:end-1,:); % Z_tmoins1 goes from 1994:Q2 to 2019:Q3

% HP-filtered natural NS factors
L_star = factors_star(:,1);
S_star = factors_star(:,2);
C_star = factors_star(:,3);
REER_star = macro_star(:,1);
Fin_star = macro_star(:,2);
Ob_star = macro_star(:,3);
y_star = macro_star(:,4);
g_star = macro_star(:,5);
Cap_star = macro_star(:,6);

%% Feedback matrix A: beta_L*,beta_S*,beta_C*,beta_REER*,beta_Fin*,beta_Ob*,beta_y*,beta_g*,beta_Cap* (State Equation 39)
%% Level*
L_star_t_1=[];
L_star_t_moins1_1=[];
L_star_t_moins1_2=[];
L_star_t_moins1_3=[];

% L_{t,1}
for i=4:3:size(L_star,1)
    L_star_t_1=[L_star_t_1;L_star(i+2)];
    L_star_t_moins1_1=[L_star_t_moins1_1;L_star(i-1)];
    L_star_t_moins1_2=[L_star_t_moins1_2;L_star(i-2)];
    L_star_t_moins1_3=[L_star_t_moins1_3;L_star(i-3)];   
end
L_star_t_moins1=L_star_t_moins1_1+L_star_t_moins1_2+L_star_t_moins1_3;
State_coeffL1=fitlm(L_star_t_moins1,L_star_t_1,'Intercept',false);
w_L1_star=table2array(State_coeffL1.Residuals(:,1));

% L_{t,2}
L_star_t_2=[];
for i=3:3:size(L_star,1)-1
    L_star_t_2=[L_star_t_2;L_star(i+2)];
end
State_coeffL2=fitlm(L_star_t_moins1,L_star_t_2,'Intercept',false);
w_L2_star=table2array(State_coeffL2.Residuals(:,1));

% L_{t,3}
L_star_t_3=[];
for i=2:3:size(L_star,1)-2
    L_star_t_3=[L_star_t_3;L_star(i+2)];
end
State_coeffL3=fitlm(L_star_t_moins1,L_star_t_3,'Intercept',false); % beta
w_L3_star=table2array(State_coeffL3.Residuals(:,1));

% beta_L_star is the average of the coefficients
beta_L_star=mean([table2array(State_coeffL1.Coefficients(1,1)),table2array(State_coeffL2.Coefficients(1,1)),table2array(State_coeffL3.Coefficients(1,1))]);

%% Slope* 
S_star_t_1=[];
S_star_t_moins1_1=[];
S_star_t_moins1_2=[];
S_star_t_moins1_3=[];

for i=4:3:size(S_star,1)
    S_star_t_1=[S_star_t_1;S_star(i+2)];
    S_star_t_moins1_1=[S_star_t_moins1_1;S_star(i-1)];
    S_star_t_moins1_2=[S_star_t_moins1_2;S_star(i-2)];
    S_star_t_moins1_3=[S_star_t_moins1_3;S_star(i-3)];
end    

S_star_t_moins1=S_star_t_moins1_1+S_star_t_moins1_2+S_star_t_moins1_3;

State_coeffS1=fitlm(S_star_t_moins1,S_star_t_1,'Intercept',false);
w_S1_star=table2array(State_coeffS1.Residuals(:,1));

S_star_t_2=[];
for i=3:3:size(S_star,1)-1
    S_star_t_2=[S_star_t_2;S_star(i+2)];
end  

State_coeffS2=fitlm(S_star_t_moins1,S_star_t_2,'Intercept',false);
w_S2_star=table2array(State_coeffS2.Residuals(:,1));

S_star_t_3=[];
for i=2:3:size(S_star,1)-2
    S_star_t_3=[S_star_t_3;S_star(i+2)];
end  

State_coeffS3=fitlm(S_star_t_moins1,S_star_t_3,'Intercept',false);
w_S3_star=table2array(State_coeffS3.Residuals(:,1));

% beta_S_star is the average of the coefficients
beta_S_star=mean([table2array(State_coeffS1.Coefficients(1,1)),table2array(State_coeffS2.Coefficients(1,1)),table2array(State_coeffS3.Coefficients(1,1))]);

%% Curvature*
C_star_t_1=[];
C_star_t_moins1_1=[];
C_star_t_moins1_2=[];
C_star_t_moins1_3=[];

for i=4:3:size(C_star,1)
    C_star_t_1=[C_star_t_1;C_star(i+2)];
    C_star_t_moins1_1=[C_star_t_moins1_1;C_star(i-1)];
    C_star_t_moins1_2=[C_star_t_moins1_2;C_star(i-2)];
    C_star_t_moins1_3=[C_star_t_moins1_3;C_star(i-3)];
end    

C_star_t_moins1=C_star_t_moins1_1+C_star_t_moins1_2+C_star_t_moins1_3;
    
State_coeffC1=fitlm(C_star_t_moins1,C_star_t_1,'Intercept',false);
w_C1_star=table2array(State_coeffC1.Residuals(:,1));

C_star_t_2=[];
for i=3:3:size(C_star,1)-1
    C_star_t_2=[C_star_t_2;C_star(i+2)];
end

State_coeffC2=fitlm(C_star_t_moins1,C_star_t_2,'Intercept',false);
w_C2_star=table2array(State_coeffC2.Residuals(:,1));

C_star_t_3=[];
for i=2:3:size(C_star,1)-2
    C_star_t_3=[C_star_t_3;C_star(i+2)];
end

State_coeffC3=fitlm(C_star_t_moins1,C_star_t_3,'Intercept',false);
w_C3_star=table2array(State_coeffC3.Residuals(:,1));

% beta_C)_star is the average of the coefficients
beta_C_star=mean([table2array(State_coeffC1.Coefficients(1,1)),table2array(State_coeffC2.Coefficients(1,1)),table2array(State_coeffC3.Coefficients(1,1))]);

%% REER*
REER_star_t=REER_star(2:end,1);
REER_star_t_moins1=REER_star(1:end-1,1);
State_coeffREER=fitlm(REER_star_t_moins1,REER_star_t,'Intercept',false);
beta_REER_star=table2array(State_coeffREER.Coefficients(1,1));
w_REER_star=table2array(State_coeffREER.Residuals(:,1));

%% Fin*
Fin_star_t=Fin_star(2:end,1);
Fin_star_t_moins1=Fin_star(1:end-1,1);
State_coeffFin=fitlm(Fin_star_t_moins1,Fin_star_t,'Intercept',false);
beta_Fin_star=table2array(State_coeffFin.Coefficients(1,1));
w_Fin_star=table2array(State_coeffFin.Residuals(:,1));

%% Ob*
Ob_star_t=Ob_star(2:end,1);
Ob_star_t_moins1=Ob_star(1:end-1,1);
State_coeffOb=fitlm(Ob_star_t_moins1,Ob_star_t,'Intercept',false);
beta_Ob_star=table2array(State_coeffOb.Coefficients(1,1));
w_Ob_star=table2array(State_coeffOb.Residuals(:,1));

%% g*
g_star_t=g_star(2:end,1);
g_star_t_moins1=g_star(1:end-1,1);
State_coeffg=fitlm(g_star_t_moins1,g_star_t,'Intercept',false);
beta_g_star=table2array(State_coeffg.Coefficients(1,1));
w_g_star=table2array(State_coeffg.Residuals(:,1));

%% y*
y_star_t=y_star(2:end,1);
y_star_t_moins1=y_star(1:end-1,1);
State_coeffy=fitlm(y_star_t_moins1+g_star_t_moins1,y_star_t,'Intercept',false);
w_y_star=table2array(State_coeffy.Residuals(:,1));

%% Cap*
Cap_star_t=Cap_star(2:end,1);
Cap_star_t_moins1=Cap_star(1:end-1,1);
State_coeffCap=fitlm(Cap_star_t_moins1,Cap_star_t,'Intercept',false);
beta_Cap_star=table2array(State_coeffCap.Coefficients(1,1));
w_Cap_star=table2array(State_coeffCap.Residuals(:,1));

%% Variance-covariance matrix Omega_1: (Equation 39)
% sqrt(var()) if Omega_1*Omega_1' in KF_MODEL
delta_L_star=var(mean(w_L1_star+w_L2_star+w_L3_star,2));
delta_S_star=var(mean(w_S1_star+w_S2_star+w_S3_star,2));
delta_C_star=var(mean(w_C1_star+w_C2_star+w_C3_star,2));
delta_REER_star=var(w_REER_star);
delta_Fin_star=var(w_Fin_star);
delta_Ob_star=var(w_Ob_star);
delta_y_star=var(w_y_star);
delta_g_star=var(w_g_star);
delta_Cap_star=var(w_Cap_star);

%% Matrix D, Measurement equation (39)
% Build X_t
X_t=[L_star_t_1,L_star_t_2,L_star_t_3,S_star_t_1,S_star_t_2,S_star_t_3,C_star_t_1,C_star_t_2,C_star_t_3,...
     REER_star_t,Fin_star_t,Ob_star_t,y_star_t,g_star_t,Cap_star_t];
 % Build X_t_moins1
X_t_moins1=[L_star_t_moins1_1,L_star_t_moins1_2,L_star_t_moins1_3,S_star_t_moins1_1,S_star_t_moins1_2,S_star_t_moins1_3,...
    C_star_t_moins1_1,C_star_t_moins1_2,C_star_t_moins1_3,REER_star_t_moins1,Fin_star_t_moins1,Ob_star_t_moins1,y_star_t_moins1,g_star_t_moins1,Cap_star_t_moins1];

% Line per line regressions

%% Lt_1
Measurement_coeffLt_1=fitlm([(Y_t_moins1(:,1)-X_t_moins1(:,1))+(Y_t_moins1(:,2)-X_t_moins1(:,2))+(Y_t_moins1(:,3)-X_t_moins1(:,3)),... % Phi_L
                             Y_t_moins1(:,10)-X_t_moins1(:,10),... % Phi_LREER
                             Y_t_moins1(:,11)-X_t_moins1(:,11),... % Phi_LFin
                             Y_t_moins1(:,12)-X_t_moins1(:,12),... % Phi_LOb
                             Y_t_moins1(:,14),... % Phi_LPi
                             Z_t_moins1(:,1),... % alpha_1
                             Z_t_moins1(:,2)],... % alpha_2
                             Y_t(:,1)-X_t(:,1),'Intercept',true);
% Extract coefficients                        
omega_L_1=table2array(Measurement_coeffLt_1.Coefficients(1,1));
Phi_L_1=table2array(Measurement_coeffLt_1.Coefficients(2,1));
Phi_LREER_1=table2array(Measurement_coeffLt_1.Coefficients(3,1));
Phi_LFin_1=table2array(Measurement_coeffLt_1.Coefficients(4,1));
Phi_LOb_1=table2array(Measurement_coeffLt_1.Coefficients(5,1));
Phi_LPi_1=table2array(Measurement_coeffLt_1.Coefficients(6,1));
alpha1_1=table2array(Measurement_coeffLt_1.Coefficients(7,1));
alpha2_1=table2array(Measurement_coeffLt_1.Coefficients(8,1));
u_L_1=table2array(Measurement_coeffLt_1.Residuals(:,1));     

%% Lt_2
Measurement_coeffLt_2=fitlm([(Y_t_moins1(:,1)-X_t_moins1(:,1))+(Y_t_moins1(:,2)-X_t_moins1(:,2))+(Y_t_moins1(:,3)-X_t_moins1(:,3)),... % Phi_L
                             Y_t_moins1(:,10)-X_t_moins1(:,10),... % Phi_LREER
                             Y_t_moins1(:,11)-X_t_moins1(:,11),... % Phi_LFin
                             Y_t_moins1(:,12)-X_t_moins1(:,12),... % Phi_LOb
                             Y_t_moins1(:,14),... % Phi_LPi
                             Z_t_moins1(:,1),... % alpha_1
                             Z_t_moins1(:,2)],... % alpha_2
                             Y_t(:,2)-X_t(:,2),'Intercept',true);
% Extract coefficients                        
omega_L_2=table2array(Measurement_coeffLt_2.Coefficients(1,1));
Phi_L_2=table2array(Measurement_coeffLt_2.Coefficients(2,1));
Phi_LREER_2=table2array(Measurement_coeffLt_2.Coefficients(3,1));
Phi_LFin_2=table2array(Measurement_coeffLt_2.Coefficients(4,1));
Phi_LOb_2=table2array(Measurement_coeffLt_2.Coefficients(5,1));
Phi_LPi_2=table2array(Measurement_coeffLt_2.Coefficients(6,1));
alpha1_2=table2array(Measurement_coeffLt_2.Coefficients(7,1));
alpha2_2=table2array(Measurement_coeffLt_2.Coefficients(8,1));
u_L_2=table2array(Measurement_coeffLt_2.Residuals(:,1));

%% Lt_3
Measurement_coeffLt_3=fitlm([(Y_t_moins1(:,1)-X_t_moins1(:,1))+(Y_t_moins1(:,2)-X_t_moins1(:,2))+(Y_t_moins1(:,3)-X_t_moins1(:,3)),... % Phi_L
                             Y_t_moins1(:,10)-X_t_moins1(:,10),... % Phi_LREER
                             Y_t_moins1(:,11)-X_t_moins1(:,11),... % Phi_LFin
                             Y_t_moins1(:,12)-X_t_moins1(:,12),... % Phi_LOb
                             Y_t_moins1(:,14),... % Phi_LPi
                             Z_t_moins1(:,1),... % alpha_1
                             Z_t_moins1(:,2)],... % alpha_2
                             Y_t(:,3)-X_t(:,3),'Intercept',true);
% Extract coefficients                        
omega_L_3=table2array(Measurement_coeffLt_3.Coefficients(1,1));
Phi_L_3=table2array(Measurement_coeffLt_3.Coefficients(2,1));
Phi_LREER_3=table2array(Measurement_coeffLt_3.Coefficients(3,1));
Phi_LFin_3=table2array(Measurement_coeffLt_3.Coefficients(4,1));
Phi_LOb_3=table2array(Measurement_coeffLt_3.Coefficients(5,1));
Phi_LPi_3=table2array(Measurement_coeffLt_3.Coefficients(6,1));
alpha1_3=table2array(Measurement_coeffLt_3.Coefficients(7,1));
alpha2_3=table2array(Measurement_coeffLt_3.Coefficients(8,1));
u_L_3=table2array(Measurement_coeffLt_3.Residuals(:,1));

% Take averages
omega_L=mean([omega_L_1,omega_L_2,omega_L_3]);
Phi_L=mean([Phi_L_1,Phi_L_2,Phi_L_3]);
Phi_LREER=mean([Phi_LREER_1,Phi_LREER_2,Phi_LREER_3]);
Phi_LFin=mean([Phi_LFin_1,Phi_LFin_2,Phi_LFin_3]);
Phi_LOb=mean([Phi_LOb_1,Phi_LOb_2,Phi_LOb_3]);
Phi_LPi=mean([Phi_LPi_1,Phi_LPi_2,Phi_LPi_3]);
alpha_1=mean([alpha1_1,alpha1_2,alpha1_3]);
alpha_2=mean([alpha2_1,alpha2_2,alpha2_3]);
delta_L=var(mean([u_L_1,u_L_2,u_L_3],2));

%% St_1
Measurement_coeffSt_1=fitlm([(Y_t_moins1(:,4)-X_t_moins1(:,4))+(Y_t_moins1(:,5)-X_t_moins1(:,5))+(Y_t_moins1(:,6)-X_t_moins1(:,6)),... % Phi_S
                             Y_t_moins1(:,10)-X_t_moins1(:,10),... % Phi_SREER
                             Y_t_moins1(:,11)-X_t_moins1(:,11),... % Phi_SFin
                             Y_t_moins1(:,12)-X_t_moins1(:,12),... % Phi_SOb
                             Y_t_moins1(:,14),... % Phi_SPi
                             Z_t_moins1(:,1),... % beta_1
                             Z_t_moins1(:,2)],... % beta_2
                             Y_t(:,4)-X_t(:,4),'Intercept',true);
% Extract coefficients                        
omega_S_1=table2array(Measurement_coeffSt_1.Coefficients(1,1));
Phi_S_1=table2array(Measurement_coeffSt_1.Coefficients(2,1));
Phi_SREER_1=table2array(Measurement_coeffSt_1.Coefficients(3,1));
Phi_SFin_1=table2array(Measurement_coeffSt_1.Coefficients(4,1));
Phi_SOb_1=table2array(Measurement_coeffSt_1.Coefficients(5,1));
Phi_SPi_1=table2array(Measurement_coeffSt_1.Coefficients(6,1));
beta1_1=table2array(Measurement_coeffSt_1.Coefficients(7,1));
beta2_1=table2array(Measurement_coeffSt_1.Coefficients(8,1));
u_S_1=table2array(Measurement_coeffSt_1.Residuals(:,1));     

%% St_2
Measurement_coeffSt_2=fitlm([(Y_t_moins1(:,4)-X_t_moins1(:,4))+(Y_t_moins1(:,5)-X_t_moins1(:,5))+(Y_t_moins1(:,6)-X_t_moins1(:,6)),... % Phi_S
                             Y_t_moins1(:,10)-X_t_moins1(:,10),... % Phi_SREER
                             Y_t_moins1(:,11)-X_t_moins1(:,11),... % Phi_SFin
                             Y_t_moins1(:,12)-X_t_moins1(:,12),... % Phi_SOb
                             Y_t_moins1(:,14),... % Phi_SPi
                             Z_t_moins1(:,1),... % beta_1
                             Z_t_moins1(:,2)],... % beta_2
                             Y_t(:,5)-X_t(:,5),'Intercept',true);
% Extract coefficients                        
omega_S_2=table2array(Measurement_coeffSt_2.Coefficients(1,1));
Phi_S_2=table2array(Measurement_coeffSt_2.Coefficients(2,1));
Phi_SREER_2=table2array(Measurement_coeffSt_2.Coefficients(3,1));
Phi_SFin_2=table2array(Measurement_coeffSt_2.Coefficients(4,1));
Phi_SOb_2=table2array(Measurement_coeffSt_2.Coefficients(5,1));
Phi_SPi_2=table2array(Measurement_coeffSt_2.Coefficients(6,1));
beta1_2=table2array(Measurement_coeffSt_2.Coefficients(7,1));
beta2_2=table2array(Measurement_coeffSt_2.Coefficients(8,1));
u_S_2=table2array(Measurement_coeffSt_2.Residuals(:,1));

%% St_3
Measurement_coeffSt_3=fitlm([(Y_t_moins1(:,4)-X_t_moins1(:,4))+(Y_t_moins1(:,5)-X_t_moins1(:,5))+(Y_t_moins1(:,6)-X_t_moins1(:,6)),... % Phi_S
                             Y_t_moins1(:,10)-X_t_moins1(:,10),... % Phi_SREER
                             Y_t_moins1(:,11)-X_t_moins1(:,11),... % Phi_SFin
                             Y_t_moins1(:,12)-X_t_moins1(:,12),... % Phi_SOb
                             Y_t_moins1(:,14),... % Phi_SPi
                             Z_t_moins1(:,1),... % beta_1
                             Z_t_moins1(:,2)],... % beta_2
                             Y_t(:,6)-X_t(:,6),'Intercept',true);
% Extract coefficients                        
omega_S_3=table2array(Measurement_coeffSt_3.Coefficients(1,1));
Phi_S_3=table2array(Measurement_coeffSt_3.Coefficients(2,1));
Phi_SREER_3=table2array(Measurement_coeffSt_3.Coefficients(3,1));
Phi_SFin_3=table2array(Measurement_coeffSt_3.Coefficients(4,1));
Phi_SOb_3=table2array(Measurement_coeffSt_3.Coefficients(5,1));
Phi_SPi_3=table2array(Measurement_coeffSt_3.Coefficients(6,1));
beta1_3=table2array(Measurement_coeffSt_3.Coefficients(7,1));
beta2_3=table2array(Measurement_coeffSt_3.Coefficients(8,1));
u_S_3=table2array(Measurement_coeffSt_3.Residuals(:,1));

% Take averages
omega_S=mean([omega_S_1,omega_S_2,omega_S_3]);
Phi_S=mean([Phi_S_1,Phi_S_2,Phi_S_3]);
Phi_SREER=mean([Phi_SREER_1,Phi_SREER_2,Phi_SREER_3]);
Phi_SFin=mean([Phi_SFin_1,Phi_SFin_2,Phi_SFin_3]);
Phi_SOb=mean([Phi_SOb_1,Phi_SOb_2,Phi_SOb_3]);
Phi_SPi=mean([Phi_SPi_1,Phi_SPi_2,Phi_SPi_3]);
beta_1=mean([beta1_1,beta1_2,beta1_3]);
beta_2=mean([beta2_1,beta2_2,beta2_3]);
delta_S=var(mean([u_S_1,u_S_2,u_S_3],2));

%% Ct_1
Measurement_coeffCt_1=fitlm([(Y_t_moins1(:,7)-X_t_moins1(:,7))+(Y_t_moins1(:,8)-X_t_moins1(:,8))+(Y_t_moins1(:,9)-X_t_moins1(:,9)),... % Phi_C
                             Y_t_moins1(:,10)-X_t_moins1(:,10),... % Phi_CREER
                             Y_t_moins1(:,11)-X_t_moins1(:,11),... % Phi_CFin
                             Y_t_moins1(:,12)-X_t_moins1(:,12),... % Phi_COb
                             Y_t_moins1(:,14),... % Phi_CPi
                             Z_t_moins1(:,1),... % gamma_1
                             Z_t_moins1(:,2)],... % gamma_2
                             Y_t(:,7)-X_t(:,7),'Intercept',true);
% Extract coefficients                        
omega_C_1=table2array(Measurement_coeffCt_1.Coefficients(1,1));
Phi_C_1=table2array(Measurement_coeffCt_1.Coefficients(2,1));
Phi_CREER_1=table2array(Measurement_coeffCt_1.Coefficients(3,1));
Phi_CFin_1=table2array(Measurement_coeffCt_1.Coefficients(4,1));
Phi_COb_1=table2array(Measurement_coeffCt_1.Coefficients(5,1));
Phi_CPi_1=table2array(Measurement_coeffCt_1.Coefficients(6,1));
gamma1_1=table2array(Measurement_coeffCt_1.Coefficients(7,1));
gamma2_1=table2array(Measurement_coeffCt_1.Coefficients(8,1));
u_C_1=table2array(Measurement_coeffCt_1.Residuals(:,1));     

%% Ct_2
Measurement_coeffCt_2=fitlm([(Y_t_moins1(:,7)-X_t_moins1(:,7))+(Y_t_moins1(:,8)-X_t_moins1(:,8))+(Y_t_moins1(:,9)-X_t_moins1(:,9)),... % Phi_C
                             Y_t_moins1(:,10)-X_t_moins1(:,10),... % Phi_CREER
                             Y_t_moins1(:,11)-X_t_moins1(:,11),... % Phi_CFin
                             Y_t_moins1(:,12)-X_t_moins1(:,12),... % Phi_COb
                             Y_t_moins1(:,14),... % Phi_CPi
                             Z_t_moins1(:,1),... % gamma_1
                             Z_t_moins1(:,2)],... % gamma_2
                             Y_t(:,9)-X_t(:,9),'Intercept',true);
% Extract coefficients                        
omega_C_2=table2array(Measurement_coeffCt_2.Coefficients(1,1));
Phi_C_2=table2array(Measurement_coeffCt_2.Coefficients(2,1));
Phi_CREER_2=table2array(Measurement_coeffCt_2.Coefficients(3,1));
Phi_CFin_2=table2array(Measurement_coeffCt_2.Coefficients(4,1));
Phi_COb_2=table2array(Measurement_coeffCt_2.Coefficients(5,1));
Phi_CPi_2=table2array(Measurement_coeffCt_2.Coefficients(6,1));
gamma1_2=table2array(Measurement_coeffCt_2.Coefficients(7,1));
gamma2_2=table2array(Measurement_coeffCt_2.Coefficients(8,1));
u_C_2=table2array(Measurement_coeffCt_2.Residuals(:,1));

%% Ct_3
Measurement_coeffCt_3=fitlm([(Y_t_moins1(:,7)-X_t_moins1(:,7))+(Y_t_moins1(:,8)-X_t_moins1(:,8))+(Y_t_moins1(:,9)-X_t_moins1(:,9)),... % Phi_C
                             Y_t_moins1(:,10)-X_t_moins1(:,10),... % Phi_CREER
                             Y_t_moins1(:,11)-X_t_moins1(:,11),... % Phi_CFin
                             Y_t_moins1(:,12)-X_t_moins1(:,12),... % Phi_COb
                             Y_t_moins1(:,14),... % Phi_CPi
                             Z_t_moins1(:,1),... % gamma_1
                             Z_t_moins1(:,2)],... % gamma_2
                             Y_t(:,9)-X_t(:,9),'Intercept',true);
% Extract coefficients                        
omega_C_3=table2array(Measurement_coeffCt_3.Coefficients(1,1));
Phi_C_3=table2array(Measurement_coeffCt_3.Coefficients(2,1));
Phi_CREER_3=table2array(Measurement_coeffCt_3.Coefficients(3,1));
Phi_CFin_3=table2array(Measurement_coeffCt_3.Coefficients(4,1));
Phi_COb_3=table2array(Measurement_coeffCt_3.Coefficients(5,1));
Phi_CPi_3=table2array(Measurement_coeffCt_3.Coefficients(6,1));
gamma1_3=table2array(Measurement_coeffCt_3.Coefficients(7,1));
gamma2_3=table2array(Measurement_coeffCt_3.Coefficients(8,1));
u_C_3=table2array(Measurement_coeffCt_3.Residuals(:,1));

% Take averages
omega_C=mean([omega_C_1,omega_C_2,omega_C_3]);
Phi_C=mean([Phi_C_1,Phi_C_2,Phi_C_3]);
Phi_CREER=mean([Phi_CREER_1,Phi_CREER_2,Phi_CREER_3]);
Phi_CFin=mean([Phi_CFin_1,Phi_CFin_2,Phi_CFin_3]);
Phi_COb=mean([Phi_COb_1,Phi_COb_2,Phi_COb_3]);
Phi_CPi=mean([Phi_CPi_1,Phi_CPi_2,Phi_CPi_3]);
gamma_1=mean([gamma1_1,gamma1_2,gamma1_3]);
gamma_2=mean([gamma2_1,gamma2_2,gamma2_3]);
delta_C=var(mean([u_C_1,u_C_2,u_C_3],2));

%% REER
Measurement_coeffREERt=fitlm([(Y_t_moins1(:,10)-X_t_moins1(:,10)),... % Phi_REER
                             Z_t_moins1(:,2),... % kappa_1
                             Z_t_moins1(:,3),... % kappa_2
                             Z_t_moins1(:,4),... % kappa_3
                             Z_t_moins1(:,5),... % kappa_4
                             Z_t_moins1(:,6),... % kappa_5
                             Z_t_moins1(:,7),... % kappa_6
                             Z_t_moins1(:,8)],...% kappa_7
                             Y_t(:,10)-X_t(:,10),'Intercept',true);

% Extract coefficients                        
omega_REER=table2array(Measurement_coeffREERt.Coefficients(1,1));
Phi_REER=table2array(Measurement_coeffREERt.Coefficients(2,1));
kappa_1=table2array(Measurement_coeffREERt.Coefficients(3,1));
kappa_2=table2array(Measurement_coeffREERt.Coefficients(4,1));
kappa_3=table2array(Measurement_coeffREERt.Coefficients(5,1));
kappa_4=table2array(Measurement_coeffREERt.Coefficients(6,1));
kappa_5=table2array(Measurement_coeffREERt.Coefficients(7,1));
kappa_6=table2array(Measurement_coeffREERt.Coefficients(8,1));
kappa_7=table2array(Measurement_coeffREERt.Coefficients(9,1));
delta_REER=var(table2array(Measurement_coeffREERt.Residuals(:,1)));

%% Fin
Measurement_coeffFint=fitlm([(Y_t_moins1(:,11)-X_t_moins1(:,11)),... % Phi_Fin
                             Z_t_moins1(:,2),...  % xi_1
                             Z_t_moins1(:,9),...  % xi_2
                             Z_t_moins1(:,10),... % xi_3
                             Z_t_moins1(:,11),... % xi_4
                             Z_t_moins1(:,12)],...% xi_5
                             Y_t(:,11)-X_t(:,11),'Intercept',true);

% Extract coefficients                        
omega_Fin=table2array(Measurement_coeffFint.Coefficients(1,1));
Phi_Fin=table2array(Measurement_coeffFint.Coefficients(2,1));
xi_1=table2array(Measurement_coeffFint.Coefficients(3,1));
xi_2=table2array(Measurement_coeffFint.Coefficients(4,1));
xi_3=table2array(Measurement_coeffFint.Coefficients(5,1));
xi_4=table2array(Measurement_coeffFint.Coefficients(6,1));
xi_5=table2array(Measurement_coeffFint.Coefficients(7,1));
delta_Fin=var(table2array(Measurement_coeffFint.Residuals(:,1)));

%% Ob
Measurement_coeffObt=fitlm([(Y_t_moins1(:,12)-X_t_moins1(:,12)),... % Phi_Ob
                             Z_t_moins1(:,13),...  % psi_1
                             Z_t_moins1(:,14),...  % psi_2
                             Z_t_moins1(:,15)],... % psi_3
                             Y_t(:,12)-X_t(:,12),'Intercept',true);

% Extract coefficients                        
omega_Ob=table2array(Measurement_coeffObt.Coefficients(1,1));
Phi_Ob=table2array(Measurement_coeffObt.Coefficients(2,1));
psi_1=table2array(Measurement_coeffObt.Coefficients(3,1));
psi_2=table2array(Measurement_coeffObt.Coefficients(4,1));
psi_3=table2array(Measurement_coeffObt.Coefficients(5,1));
delta_Ob=var(table2array(Measurement_coeffObt.Residuals(:,1)));

%% Pi
Measurement_coeffPit=fitlm([(Y_t_moins1(:,14)),... % Phi_Pi
                             Y_t_moins1(:,15)-X_t_moins1(:,15),... % Phi_PiCap
                             Z_t_moins1(:,6),...  % mu_1
                             Z_t_moins1(:,13),... % mu_2
                             Z_t_moins1(:,14),... % mu_3
                             Z_t_moins1(:,15)],...% mu_4
                             Y_t(:,14),'Intercept',true);

% Extract coefficients                        
omega_Pi=table2array(Measurement_coeffPit.Coefficients(1,1));
Phi_Pi=table2array(Measurement_coeffPit.Coefficients(2,1));
Phi_PiCap=table2array(Measurement_coeffPit.Coefficients(3,1));
mu_1=table2array(Measurement_coeffPit.Coefficients(4,1));
mu_2=table2array(Measurement_coeffPit.Coefficients(5,1));
mu_3=table2array(Measurement_coeffPit.Coefficients(6,1));
mu_4=table2array(Measurement_coeffPit.Coefficients(7,1));
delta_Pi=var(table2array(Measurement_coeffPit.Residuals(:,1)));

%% Cap
Measurement_coeffCapt=fitlm([(Y_t_moins1(:,15)-X_t_moins1(:,15)),... % Phi_Cap
                             Y_t_moins1(:,13)-X_t_moins1(:,13)],... % Phi_Capy
                             Y_t(:,15)-X_t(:,15),'Intercept',true);

% Extract coefficients                        
omega_Cap=table2array(Measurement_coeffCapt.Coefficients(1,1));
Phi_Cap=table2array(Measurement_coeffCapt.Coefficients(2,1));
Phi_Capy=table2array(Measurement_coeffCapt.Coefficients(3,1));
delta_Cap=var(table2array(Measurement_coeffCapt.Residuals(:,1)));

%% y (MIDAS)
% yield curve gap
yield_curve_gap=[Y_t(:,1)-L_star_t_1,Y_t(:,2)-L_star_t_2,Y_t(:,3)-L_star_t_3,... % Level gap
   Y_t(:,4)-S_star_t_1,Y_t(:,5)-S_star_t_2,Y_t(:,6)-S_star_t_3,... % Slope gap
   Y_t(:,7)-C_star_t_1,Y_t(:,8)-C_star_t_2,Y_t(:,9)-C_star_t_3];

% Build bL/bS/bC
% Initial guess for initial values of omega_y, mu, Phi_y and Phi_yob
% Pre-allocate
loading=NaN(N,3);
% Loop over each maturity
for n=1:N % Be careful if 20-year bond is included
   loading(n,1)=1; % Level
   loading(n,2)=(1-exp(-n/lambda))/(n/lambda); % Slope
   loading(n,3)=((1-exp(-n/lambda))/(n/lambda))-exp(-n/lambda); % Curvature
end
for i=1:3 % Be careful if 20-year bond is included
    MU_guess(i)=(1/N)*sum(loading(1:N,i),1);
end

% Quarterly yield curve gap
Quarterly_Factor_gap=NaN(size(Y_t,1),3);
for t=1:size(Y_t,1)
    Quarterly_Factor_gap(t,:)=[mean(yield_curve_gap(t,1:3),2),mean(yield_curve_gap(t,4:6),2),mean(yield_curve_gap(t,7:9),2)]; % Mean of the quarters
end

% OLS estimation
Measurement_coeffyt=fitlm([(Y_t_moins1(:,13)-X_t_moins1(:,13)),... % Phi_y
                             MU_guess(1)*Quarterly_Factor_gap(:,1)+... % mu (L-L*)
                             MU_guess(2)*Quarterly_Factor_gap(:,2)+... % mu (S-S*)
                             MU_guess(3)*Quarterly_Factor_gap(:,3),... % mu (C-C*)
                             Y_t_moins1(:,12)-X_t_moins1(:,12)],... % Phi_yOB
                             Y_t(:,13)-X_t(:,13),'Intercept',true); % y-y*

% Extract coefficients as initialization of MLE                 
omega_y_guess=table2array(Measurement_coeffyt.Coefficients(1,1));
mu_guess=table2array(Measurement_coeffyt.Coefficients(2,1));
Phi_y_guess=table2array(Measurement_coeffyt.Coefficients(3,1));
Phi_yOB_guess=table2array(Measurement_coeffyt.Coefficients(4,1));
delta_y_guess=var(table2array(Measurement_coeffyt.Residuals(:,1)));

% Build theta_guess (user's best guess...)
theta_guess=NaN(3,2);
for i=1:3
    theta_guess(i,1)=0.02; % Values as in Ghysel paper on MIDAS Regressions are 6*10-3 and -5*10-4, we want a faster decline. Our values enable no weight after 6 months
    theta_guess(i,2)=-0.2; % Negative to ensure declining weight
end    

% Gather guessed parameters
theta_guess=reshape(theta_guess,6,1);
Zeta0=[omega_y_guess;Phi_y_guess;mu_guess;theta_guess;Phi_yOB_guess;delta_y_guess];

% Build LHS of Equation 27: y-y_star
LHS=Y_t(:,13)-y_star_t;

% Build RHS of Equation 27: L-L_star, S-S_star, C-C_star, Ob-Ob_star
RHS=[Y_t_moins1(:,13)-y_star_t_moins1,... % output gap
   Y_t_moins1(:,1)-L_star_t_moins1_1,Y_t_moins1(:,2)-L_star_t_moins1_2,Y_t_moins1(:,3)-L_star_t_moins1_3,... % Level gap
   Y_t_moins1(:,4)-S_star_t_moins1_1,Y_t_moins1(:,5)-S_star_t_moins1_2,Y_t_moins1(:,6)-S_star_t_moins1_3,... % Slope gap
   Y_t_moins1(:,7)-C_star_t_moins1_1,Y_t_moins1(:,8)-C_star_t_moins1_2,Y_t_moins1(:,9)-C_star_t_moins1_3,... % Curvature gap
   Y_t_moins1(:,12)-Ob_star_t_moins1]; % Ob gap

% MLE
[lb,ub]=restrictions(Zeta0,'INIT');
options_init=optionsetting(10e-6,10e-6,10e3,'fmincon','sqp','off','none',[]); % optionsetting(Tolfun,TolX,Maxfunevals,funct,algo,diag,disp,progress) algo is 'interior-point' (default) or 'sqp'
%disp('-------------Likelihood Maximization for initialization of parameters---------------')
epsilon = 1e3;
while epsilon > 1e-8
    [Zeta,ENERGY] = fmincon(@(Zeta)init_theta_MODEL(Zeta,lambda,jmax,N,LHS,RHS,1),Zeta0,[],[],[],[],lb,ub,[],options_init);
    epsilon = abs(Zeta-Zeta0);
    epsilon = max(epsilon);
    Zeta0=Zeta;
end

% Optimized parameters
omega_y=Zeta(1);
Phi_y=Zeta(2);
mu=Zeta(3);
theta1L=Zeta(4);
theta2L=Zeta(5);
theta1S=Zeta(6);
theta2S=Zeta(7);
theta1C=Zeta(8);
theta2C=Zeta(9);
Phi_yOb=Zeta(10);

% Compute residual with optimized parameters
u_y=init_theta_MODEL(Zeta,lambda,jmax,N,LHS,RHS,2);
delta_y=var(u_y);

%% Gather results
Psi0=[omega_L;omega_S;omega_C;omega_REER;omega_Fin;omega_Ob;omega_y;omega_Pi;omega_Cap;...
    Phi_L;Phi_S;Phi_C;Phi_REER;Phi_Fin;Phi_Ob;Phi_LREER;Phi_LFin;Phi_LOb;Phi_LPi;...
    Phi_SREER;Phi_SFin;Phi_SOb;Phi_SPi;Phi_CREER;Phi_CFin;Phi_COb;Phi_CPi;...
    Phi_yOb;Phi_y;Phi_Pi;Phi_PiCap;Phi_Capy;Phi_Cap;...
    mu;theta1L;theta2L;theta1S;theta2S;theta1C;theta2C;...
    alpha_1;alpha_2;beta_1;beta_2;gamma_1;gamma_2;kappa_1;kappa_2;kappa_3;kappa_4;kappa_5;kappa_6;kappa_7;...
    xi_1;xi_2;xi_3;xi_4;xi_5;psi_1;psi_2;psi_3;mu_1;mu_2;mu_3;mu_4;...
    beta_L_star;beta_S_star;beta_C_star;beta_REER_star;beta_Fin_star;beta_Ob_star;beta_g_star;beta_Cap_star;...
    delta_L;delta_S;delta_C;delta_REER;delta_Fin;delta_Ob;delta_y;delta_Pi;delta_Cap;...
    delta_L_star;delta_S_star;delta_C_star;delta_REER_star;delta_Fin_star;delta_Ob_star;delta_y_star;delta_g_star;delta_Cap_star];

disp('Parameters initialized');

end