function p_Omega=form_density_normal(Omega,omega,Sigma)

% Normal for the AR coefficients and constant:
p_Omega=((det(2*pi*Sigma))^(-0.5))*exp(-0.5*transpose(Omega-omega)*(Sigma\eye(size(Sigma,1)))*(Omega-omega));

end