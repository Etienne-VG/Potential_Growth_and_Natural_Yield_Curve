function Scale=find_scale(var,shape)

if shape<=1
    error('Cant use var_find for shape<=1');
end

% Pre-allocate
Scale=NaN(size(var,1),1);

% Loop over scale
for i=1:size(var,1)
    Scale(i)=(shape-1)*var(i);
end

end