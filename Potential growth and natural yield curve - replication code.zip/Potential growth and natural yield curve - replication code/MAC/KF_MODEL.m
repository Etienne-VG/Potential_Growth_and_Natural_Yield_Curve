function YY = KF_MODEL(Psi,lambda,real_factors,X0F,X0M,data_endo,data_exo,prior_hyper,prior_shape,prior_beliefs,optimize,index)
% This function runs the Kalman filter for then MODEL model (step 2 in paper)

% Declare some constants
T_q = size(data_exo,1)-1; % first date is for t=t-1
nF=3*size(X0F,2); % L_1,L_2,L_3,S_1,S_2,S_3,C_1,C_2,C_3
nZ=size(X0M,2); % REER,Fin,Ob,y,pi,cap
nvar=nF+nZ; % L_1,L_2,L_3,S_1,S_2,S_3,C_1,C_2,C_3,REER,Fin,Ob,y,pi,cap

% Step 0: Set up
[A,Omega_1,C,E,D,G,B,Omega_2,Y_t,Y_tmoins1,Z_tmoins1,Psi1,Psi2,Psi3,Psi4]=Setup_KF_MODEL(Psi,lambda,real_factors,data_endo,data_exo,T_q); % Compute matrices of coefficients and variables

% Kalman Filter %

% Preallocation
Xt_1 = NaN(nvar,T_q+1);
Xt = NaN(nvar,T_q+1);
Pt_1 = NaN(nvar,nvar,T_q+1);
Pt = NaN(nvar,nvar,T_q+1);
energy = NaN(1,T_q);
ERROR=zeros(size(Y_t,1),1);

% Step 1: Initialization
Xt(:,1)=[X0F(3,1);X0F(2,1);X0F(1,1);X0F(3,2);X0F(2,2);X0F(1,2);X0F(3,3);X0F(2,3);X0F(1,3);X0M(1,1);X0M(1,2);X0M(1,3);X0M(1,4);X0M(1,5);X0M(1,6)]; % t starts in April 1994 because t-1 starts in January 1994
Pt(:,:,1)=0.02*eye(nvar);

% Step 2: Prediction
for t =1:T_q % 
    
    Xt_1(:,t) = A*Xt(:,t); % State equation
    Pt_1(:,:,t) = A*Pt(:,:,t)*A' + Omega_1; % Variance state equation
    
    Y_hat = C+E*Xt_1(:,t)+D*Xt(:,t)+G*Y_tmoins1(:,t)+B*Z_tmoins1(:,t); % Measurement equation
    F = E*Pt_1(:,:,t)*E' + Omega_2 + D*Pt(:,:,t)*D'+E*A*Pt(:,:,t)*D'+D*Pt(:,:,t)*A'*E'; % Variance measurement equation
    
    erreur = Y_t(:,t) - Y_hat;
       
    % Check if F is not inversible (wrong initial values for the parameters), then return
    if rcond(F) < 1e-8
        YY = 10^8;
        return
    else
    end
    flag = det(F);
    if (~(isfinite(flag))) || (~(flag>0))
        YY = 10^8;
        return
    else    
    end
    %}
    
    % Step 3: Update
    
    % Cholesky trick because F is usually not invertible
    H=transpose(Pt_1(:,:,t)*E'+A*Pt(:,:,t)*D');
    inv_FxH_prim=inverse_F(F,H);
    
    K = transpose(inv_FxH_prim); % Kalman gain as in our paper
    Xt(:,t+1) = Xt_1(:,t) + K*erreur;
    Pt(:,:,t+1) = Pt_1(:,:,t)-K*F*K';
        
    % Step 5: Calculate the Energy function
    energy(t) = 1/2*(size(Y_t,1)*log(2*pi)+log(det(F)) + erreur'*(F\eye(size(F,1)))*erreur); 
    
    ERROR=ERROR+erreur.^2;
end

if optimize==2 % MAP
    % Build priors
    [p_Psi1,p_Psi2]=prior_density(Psi1,Psi2,prior_hyper,prior_shape,prior_beliefs,nvar,'state','MODEL'); % State Equation
    [p_Psi3,p_Psi4]=prior_density(Psi3,Psi4,prior_hyper,prior_shape,prior_beliefs,nvar,'measurement','MODEL'); % Measurement Equation
    priors=p_Psi1*p_Psi2*p_Psi3*p_Psi4;
else
    priors=1; % MLE
end

ENERGY = sum(energy)-log(priors);

% RMSE
RMSE=sum(ERROR);
RMSE=sqrt(RMSE/(nvar*T_q));

if index==0 % MLE/MAP
    YY = ENERGY;
elseif index==1
    Xf=Xt(:,2:end)';
    YY = [Xf,repmat(RMSE,T_q,1)];
else
    YY=0;
end

end