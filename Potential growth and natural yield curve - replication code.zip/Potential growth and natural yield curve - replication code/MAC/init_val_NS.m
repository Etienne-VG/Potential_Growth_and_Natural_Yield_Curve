function [Omega0,Priors,X0]=init_val_NS(yields,maturities)
% This function runs OLS regressions to find priors of the Dynamic Nelson-Siegal model

% Values from the BoJ paper: Imakubo1, Kojima1 and Nakajima (2005)
mu=[0.019;-0.009;-0.038];
theta=reshape([0.857,0.150,0.061;0.005,0.927,0.124;-0.081,0.099,0.985],9,1);
lambda_prior=2.25; % MLE
%lambda_prior=(1/0.143); % Imakubo and al. (2017) for yearly Japanese data
%lambda_prior=(1/0.0609)/12; % Diebold, Rudebusch, Aruoba (2006) for monthly US data

%% Initial values: State Equation
% Linear combinations to approximate the latent factors
Level(:,1)=(yields(:,1)+yields(:,5)+yields(:,end))/3;
Slope(:,1)=yields(:,end)-yields(:,1);
Curvature(:,1)=2*yields(:,5)-yields(:,end)-yields(:,1);

% Equation per Equation OLS
% Level
State_Coeff_Level=fitlm([Level(1:end-1,1),Slope(1:end-1,1),Curvature(1:end-1,1)],Level(2:end,1),'Intercept',true);
mu_L=table2array(State_Coeff_Level.Coefficients(1,1));
theta_11=table2array(State_Coeff_Level.Coefficients(2,1));
theta_12=table2array(State_Coeff_Level.Coefficients(3,1));
theta_13=table2array(State_Coeff_Level.Coefficients(4,1));
zeta_L=table2array(State_Coeff_Level.Residuals(:,1));

% Slope
State_Coeff_Slope=fitlm([Level(1:end-1,1),Slope(1:end-1,1),Curvature(1:end-1,1)],Slope(2:end,1),'Intercept',true);
mu_S=table2array(State_Coeff_Slope.Coefficients(1,1));
theta_21=table2array(State_Coeff_Slope.Coefficients(2,1));
theta_22=table2array(State_Coeff_Slope.Coefficients(3,1));
theta_23=table2array(State_Coeff_Slope.Coefficients(4,1));
zeta_S=table2array(State_Coeff_Slope.Residuals(:,1));

% Curvature
State_Coeff_Curvature=fitlm([Level(1:end-1,1),Slope(1:end-1,1),Curvature(1:end-1,1)],Curvature(2:end,1),'Intercept',true);
mu_C=table2array(State_Coeff_Curvature.Coefficients(1,1));
theta_31=table2array(State_Coeff_Curvature.Coefficients(2,1));
theta_32=table2array(State_Coeff_Curvature.Coefficients(3,1));
theta_33=table2array(State_Coeff_Curvature.Coefficients(4,1));
zeta_C=table2array(State_Coeff_Curvature.Residuals(:,1));

% Variance-covariance matrix sigma_zeta
sigma_zeta_11=var(zeta_L);
sigma_zeta_12=cov(zeta_L,zeta_S);
sigma_zeta_12=sigma_zeta_12(1,2);
sigma_zeta_13=cov(zeta_L,zeta_C);
sigma_zeta_13=sigma_zeta_13(1,2);
sigma_zeta_22=var(zeta_S);
sigma_zeta_23=cov(zeta_S,zeta_C);
sigma_zeta_23=sigma_zeta_23(1,2);
sigma_zeta_33=var(zeta_C);

sigma_zeta_upper=[sigma_zeta_11;sigma_zeta_12;sigma_zeta_13;sigma_zeta_22;sigma_zeta_23;sigma_zeta_33];


%% Initial values: Measurement Equation
% Compute loadings using Imakubo et al. (2017) value of lambda
Loadings=NaN(max(maturities),3);
for n=1:max(maturities)
    Loadings(n,1)=1;
    Loadings(n,2)=(1-exp(-n/lambda_prior))/(n/lambda_prior);
    Loadings(n,3)=(1-exp(-n/lambda_prior))/(n/lambda_prior)-exp(-n/lambda_prior);  
end

% Compute sigma_epsilon
epsilon=NaN(size(yields,1),size(maturities,1));
sigma_epsilon=NaN(size(maturities,1),1);
for i=maturities'
    j=find(maturities==i);
    epsilon(:,j)=yields(:,j)-Level*Loadings(i,1)-Slope*Loadings(i,2)-Curvature*Loadings(i,3);
    sigma_epsilon(j,1)=var(epsilon(:,j));
end

%% Gather all results
Omega0=[mu_L;mu_S;mu_C;theta_11;theta_12;theta_13;theta_21;theta_22;theta_23;theta_31;theta_32;theta_33;sigma_zeta_11;sigma_zeta_12;sigma_zeta_13;sigma_zeta_22;sigma_zeta_23;sigma_zeta_33;sigma_epsilon;lambda_prior];
Priors=[mu;theta;sigma_zeta_upper;sigma_epsilon;lambda_prior];
X0=[Level,Slope,Curvature];

end