function val=form_density_wishart(Omega,S,alpha,n)

temp=NaN(5,1);

temp(1,1)=-(alpha*n/2)*log(2);
temp(2,1)=-mgamma(alpha/2,n);
temp(3,1)=(alpha/2)*log(det(S));
temp(4,1)=-((alpha+n+1)/2)*log(det(Omega));
temp(5,1)=-0.5*trace(Omega\S);

logval=sum(temp);
val=exp(logval);


