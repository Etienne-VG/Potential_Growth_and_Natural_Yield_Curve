function p_Omega=form_density_gamma(Omega,shape,scale) 

p_Omega=scale^shape/gamma(shape)*Omega.^(-shape-1).*exp(-scale./Omega);

end