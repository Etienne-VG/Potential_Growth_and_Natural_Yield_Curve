function graphs(dates,maturities,N,X,name,indice,indice2,save_output)

if indice2==0 % NS MODEL

    if indice ==1
        % Plot yield curve
        figure('Name',char(name));
        hold on
        % Plot time series
        p1=plot(maturities,median(X(:,1:N),1),'LineStyle','-','marker','x','Color',[0,0,1],'LineWidth',2.5,'DisplayName','Fitted yields');
        p2=plot(maturities,median(X(:,N+1:2*N),1),'LineStyle','--','marker','x','Color',[0,0.7,0],'LineWidth',2.5,'DisplayName','Observed yields');
        p3=plot(maturities,median(X(:,1:N),1)-median(X(:,N+1:2*N),1),'LineStyle','none','marker','x','Color',[1,0,0],'LineWidth',2.5,'DisplayName','Residuals');
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);
        hold off
        %title ('Plot','FontWeight','bold','FontSize',12)
        xlabel('Maturities (years)','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);
        legend([p1 p2 p3],'Location','northwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',18);
        set(gca,'fontsize',18);  
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\NS','\',char(name)));
        end
        
    elseif indice ==2
        figure('Name',char(name));
        [x,y]=meshgrid(maturities,dates);
        surf(x,y,X,'LineStyle','-','FaceColor','interp')
        set(gca,'Ydir','reverse')
        xlabel('Maturities (years)','FontWeight','bold','FontSize',22);
        ylabel('Dates','FontWeight','bold','FontSize',22);
        zlabel('%','FontWeight','bold','FontSize',22);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\NS','\',char(name)));
        end
        
    elseif indice ==3
        figure('Name',char(name));
        % Plot Level, Slope, Curvature
        hold on
     
        %Plot time series
        p1=plot(dates,X(:,1),'LineStyle','-','marker','none','Color',[1,0,0],'LineWidth',2.5,'DisplayName','Level');
        p2=plot(dates,X(:,2),'LineStyle','--','marker','none','Color',[0,0,1],'LineWidth',2.5,'DisplayName','Slope'); 
        p3=plot(dates,X(:,3),'LineStyle',':','marker','none','Color',[0,0.7,0],'LineWidth',2.5,'DisplayName','Curvature');  
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);

        % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');

        hold off
        ax=gca;
        xlim([1990 2020])
        ax.XTick=1990:2:2020;

        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);
        legend([p1 p2 p3],'Location','southwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\NS','\',char(name)));
        end
    elseif indice ==4
        % Plot yield curve quartiles
        figure('Name',char(name));
        hold on
        % Plot time series
        p1=plot(maturities,quantile(X(:,1:N),0.75,1),'LineStyle','--','marker','x','Color',[0,0,1],'LineWidth',2.5,'DisplayName','75th-quartile (fitted yield curve)');
        p2=plot(maturities,quantile(X(:,1:N),0.50,1),'LineStyle','-','marker','x','Color',[1,0,0],'LineWidth',2.5,'DisplayName','Median (fitted yield curve)');
        p3=plot(maturities,quantile(X(:,1:N),0.25,1),'LineStyle','-.','marker','x','Color',[0,0.7,0],'LineWidth',2.5,'DisplayName','25th-quartile (fitted yield curve)');
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);
        hold off
        %title ('Plot','FontWeight','bold','FontSize',12)
        xlabel('Maturities (years)','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);
        legend([p1 p2 p3],'Location','northwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);    
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\NS','\',char(name)));
        end
        
    elseif indice==6
        figure('Name',char(name));
        % Level, Slope, Curvature
        hold on
        % Plot time series
        p1=plot(dates,X(:,1),'LineStyle','-','marker','none','Color',[1,0,0],'LineWidth',2.5,'DisplayName','Level');
        p2=plot(dates,X(:,2),'LineStyle','--','marker','none','Color',[0,0,1],'LineWidth',2.5,'DisplayName','Slope');
        p3=plot(dates,X(:,3),'LineStyle','-.','marker','none','Color',[0,0.7,0],'LineWidth',2.5,'DisplayName','Curvature');

        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);

        % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');

        hold off
        ax=gca;
        xlim([1990 2020])
        ax.XTick=1990:2:2020;
        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);
        legend([p1,p2,p3],'Location','northwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\GATSM','\',char(name)));
        end
    
    elseif indice==7
        figure('Name',char(name));
        % Plot maturities across the sample
        hold on
        %Plot time series
        j=1;
        for i=N:-1:1
            p(j)=plot(dates,X(:,i),'LineStyle','-','marker','none','LineWidth',1.5,'DisplayName',char(strcat(num2str(maturities(i)),'Y')));
            j=j+1;
        end    
        
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);

        % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');

        hold off
        ax=gca;
        xlim([1990 2020])
        ax.XTick=1990:2:2020;

        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);
        legend(p,'Location','southwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\NS','\',char(name)));
        end
    elseif indice ==8
        % Plot loadings
        figure('Name',char(name));
        hold on
        % Plot time series
        p1=plot(maturities,X(:,1),'LineStyle','--','marker','x','Color',[0,0,1],'LineWidth',2.5,'DisplayName','Loading Level');
        p2=plot(maturities,X(:,2),'LineStyle','-','marker','x','Color',[1,0,0],'LineWidth',2.5,'DisplayName','Loading Slope');
        p3=plot(maturities,X(:,3),'LineStyle','-.','marker','x','Color',[0,0.7,0],'LineWidth',2.5,'DisplayName','Loading Curvature');
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);
        hold off
        %title ('Plot','FontWeight','bold','FontSize',12)
        xlabel('Maturities (years)','FontWeight','bold','FontSize',22);
        xlim([1 10]);
        ylabel('%','FontWeight','bold','FontSize',22);
        legend([p1 p2 p3],'Location','northwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);    
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\NS','\',char(name)));
        end 
    else
    end
    
elseif indice2==1 % MACRO MODEL (natural yields)
    
    if indice ==3
    
        % Plot gaps
        figure('Name',char(name));
        
        hold on
        %Plot time series
        p1=plot(dates,X(:,1),'LineStyle','-','marker','none','Color',[1,0,0],'LineWidth',2.5,'DisplayName',char(name(1:end-4)));
        p2=plot(dates,X(:,2),'LineStyle','--','marker','none','Color',[0,0,1],'LineWidth',2.5,'DisplayName',char(strcat('Natural',{' '},name(1:end-4)))); 
 
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);

        % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');

        hold off
        ax=gca;
        xlim([1994 2020])
        ax.XTick=1994:2:2020;

        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);
        %legend([p1 p2 p3],'Location','southwest');
        legend([p1 p2],'Location','southwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name)));
        end
        
 elseif indice ==4
        % Plot natural yield curve quartiles
        figure('Name',char(name));
        hold on
        % Plot time series
        p1=plot(maturities,quantile(X(:,1:N),0.75,1),'LineStyle','--','marker','x','Color',[0,0,1],'LineWidth',2.5,'DisplayName','75th-quartile (natural yield curve)');
        p2=plot(maturities,quantile(X(:,1:N),0.50,1),'LineStyle','-','marker','x','Color',[1,0,0],'LineWidth',2.5,'DisplayName','Median (natural yield curve)');
        p3=plot(maturities,quantile(X(:,1:N),0.25,1),'LineStyle','-.','marker','x','Color',[0,0.7,0],'LineWidth',2.5,'DisplayName','25th-quartile (natural yield curve)');
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);
        hold off
        %title ('Plot','FontWeight','bold','FontSize',12)
        xlabel('Maturities (years)','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);
        legend([p1 p2 p3],'Location','southeast');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name),'.png'));
        end
        
    elseif indice ==5
        % Plot real yield curve vs natural yield curve
        figure('Name',char(name));
        hold on
        % Plot time series
        p1=plot(maturities,median(X(:,1:N),1),'LineStyle','-','marker','x','Color',[0,0,1],'LineWidth',2.5,'DisplayName','Real yield curve (median)');
        p2=plot(maturities,median(X(:,N+1:2*N),1),'LineStyle','--','marker','x','Color',[0,0.7,0],'LineWidth',2.5,'DisplayName','Natural yield curve (median)');
        p3=plot(maturities,median(X(:,1:N)-X(:,N+1:2*N),1),'LineStyle','none','marker','x','Color',[1,0,0],'LineWidth',2.5,'DisplayName','Gap');
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);
        hold off
        %title ('Plot','FontWeight','bold','FontSize',12)
        xlabel('Maturities (years)','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);
        legend([p1 p2 p3],'Location','Northwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);      
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name),'.png'));
        end
        
    elseif indice ==6
        figure('Name',char(name));
        % Plot natural Level, Slope, Curvature
        hold on
        %Plot time series
        p1=plot(dates,X(:,1),'LineStyle','-','marker','none','Color',[1,0,0],'LineWidth',2.5,'DisplayName','Natural level');
        p2=plot(dates,X(:,2),'LineStyle','--','marker','none','Color',[0,0,1],'LineWidth',2.5,'DisplayName','Natural slope'); 
        p3=plot(dates,X(:,3),'LineStyle',':','marker','none','Color',[0,0.7,0],'LineWidth',2.5,'DisplayName','Natural curvature');
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);

        % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');


        hold off
        ax=gca;
        xlim([1994 2020])
        ax.XTick=1994:2:2020;

        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);

        legend([p1 p2 p3],'Location','southwest');

        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name)));
        end
  elseif indice ==7
        figure('Name',char(name));
        [x,y]=meshgrid(maturities,dates);
        surf(x,y,X,'LineStyle','-','FaceColor','interp')
        set(gca,'Ydir','reverse')
        xlabel('Maturities (years)','FontWeight','bold','FontSize',22);
        ylabel('Dates','FontWeight','bold','FontSize',22);
        zlabel('%','FontWeight','bold','FontSize',22);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name)));
        end    
        
    else
    end
    
elseif indice2==2 % MACRO MODEL (potential variables)
    
    if indice ==1
        
        figure('Name',char(name));
        % Plot natural potential output
        hold on
        %Plot time series
        p1=plot(dates,X(:,1),'LineStyle','-','marker','none','Color',[1,0,0],'LineWidth',2.5,'DisplayName','REER');
        p2=plot(dates,X(:,2),'LineStyle','--','marker','none','Color',[0,0,1],'LineWidth',2.5,'DisplayName','REER trend'); 
        p3=plot(dates,X(:,3),'LineStyle',':','marker','none','Color',[0,0.7,0],'LineWidth',2.5,'DisplayName','Potential REER');
 
        % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');


        hold off
        xlim([1994 2020]);
        ax=gca;
        ax.XTick=1994:2:2020;

        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('Level','FontWeight','bold','FontSize',22);
        legend([p1 p2 p3],'Location','northwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name)));
        end
        
   elseif indice ==2
        
        figure('Name',char(name));
        % Plot natural potential output
        hold on
        %Plot time series
        p1=plot(dates,X(:,1),'LineStyle','-','marker','none','Color',[1,0,0],'LineWidth',2.5,'DisplayName','Financial cycle');
        p2=plot(dates,X(:,2),'LineStyle','--','marker','none','Color',[0,0,1],'LineWidth',2.5,'DisplayName','Financial cycle trend'); 
        p3=plot(dates,X(:,3),'LineStyle',':','marker','none','Color',[0,0.7,0],'LineWidth',2.5,'DisplayName','Potential Financial cycle');
 
        % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');


        hold off
        xlim([1994 2020]);
        ax=gca;
        ax.XTick=1994:2:2020;

        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('Level','FontWeight','bold','FontSize',22);
        legend([p1 p2 p3],'Location','northwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name)));
        end
    elseif indice ==3
        
        figure('Name',char(name));
        % Plot natural potential output
        hold on
        %Plot time series
        p1=plot(dates,X(:,1),'LineStyle','-','marker','none','Color',[1,0,0],'LineWidth',2.5,'DisplayName','Overall Balance');
        p2=plot(dates,X(:,2),'LineStyle','--','marker','none','Color',[0,0,1],'LineWidth',2.5,'DisplayName','Overall Balance trend'); 
        p3=plot(dates,X(:,3),'LineStyle',':','marker','none','Color',[0,0.7,0],'LineWidth',2.5,'DisplayName','Potential Overall Balance');
 
        % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');


        hold off
        xlim([1994 2020]);
        ax=gca;
        ax.XTick=1994:2:2020;

        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('%GDP','FontWeight','bold','FontSize',22);
        legend([p1 p2 p3],'Location','northwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name)));
        end
    elseif indice ==4
        
        figure('Name',char(name));
        % Plot natural potential output
        hold on
        %Plot time series
        p1=plot(dates,X(:,1),'LineStyle','-','marker','none','Color',[1,0,0],'LineWidth',2.5,'DisplayName','Output');
        p2=plot(dates,X(:,2),'LineStyle','--','marker','none','Color',[0,0,1],'LineWidth',2.5,'DisplayName','Output trend'); 
        p3=plot(dates,X(:,3),'LineStyle',':','marker','none','Color',[0,0.7,0],'LineWidth',2.5,'DisplayName','Potential output');
 
        % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');


        hold off
        xlim([1994 2020]);
        ax=gca;
        ax.XTick=1994:2:2020;

        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('log(Level)','FontWeight','bold','FontSize',22);
        legend([p1 p2 p3],'Location','northwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name)));
        end
        
    elseif indice ==5
        
        figure('Name',char(name));
        % Plot natural potential output growth
        hold on
        %Plot time series
        p1=plot(dates,X(:,1),'LineStyle','-','marker','none','Color',[1,0,0],'LineWidth',2.5,'DisplayName','Output growth');
        p2=plot(dates,X(:,2),'LineStyle','--','marker','none','Color',[0,0,1],'LineWidth',2.5,'DisplayName','Output growth trend'); 
        p3=plot(dates,X(:,3),'LineStyle',':','marker','none','Color',[0,0.7,0],'LineWidth',2.5,'DisplayName','Potential Output growth'); 
 
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);

        % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');


        hold off
        xlim([1994 2020]);
        ax=gca;
        ax.XTick=1994:2:2020;

        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);
        legend([p1 p2 p3],'Location','southwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name)));
        end
       
    
     elseif indice ==6
        
        figure('Name',char(name));
        % Plot natural potential capacity utilization
        hold on
        %Plot time series
        p1=plot(dates,X(:,1),'LineStyle','-','marker','none','Color',[1,0,0],'LineWidth',2.5,'DisplayName','Capacity utilization');
        p2=plot(dates,X(:,2),'LineStyle','--','marker','none','Color',[0,0,1],'LineWidth',2.5,'DisplayName','Capacity utilization trend'); 
        p3=plot(dates,X(:,3),'LineStyle',':','marker','none','Color',[0,0.7,0],'LineWidth',2.5,'DisplayName','Potential capacity utilization'); 
 
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);

        % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');


        hold off
        xlim([1994 2020]);
        ax=gca;
        ax.XTick=1994:2:2020;   

        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);
        legend([p1 p2 p3],'Location','southwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name)));
        end
     
    elseif indice==7
        
        figure('Name',char(name));
        % Plot interest rate gap and macro variables
        hold on
        %Plot time series
        p1=plot(dates,X(:,1),'LineStyle','-','marker','none','Color',[1,0,0],'LineWidth',2.5,'DisplayName','r-r*');
        p2=plot(dates,X(:,2),'LineStyle','--','marker','none','Color',[0,0,1],'LineWidth',2.5,'DisplayName',char(name)); 
 
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);

        % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');


        hold off
        xlim([1994 2020]);
        ax=gca;
        ax.XTick=1994:2:2020;
        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);
        legend([p1 p2],'Location','southwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name),' with r-r star'));
        end
    
     elseif indice==8
        
        figure('Name',char(name));
        % Plot interest rate gap and macro variables
        hold on
        %Plot time series
        p1=plot(dates,X(:,1),'LineStyle','-','marker','none','Color',[1,0,0],'LineWidth',2.5,'DisplayName','Yield curve gap');
        p2=plot(dates,X(:,2),'LineStyle','--','marker','none','Color',[0,0,1],'LineWidth',2.5,'DisplayName',char(name)); 
 
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);

        % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');


        hold off
        xlim([1994 2020]);
        ax=gca;
        ax.XTick=1994:2:2020; 
        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);
        legend([p1 p2],'Location','southwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name),' with yield curve gap'));
        end
        
    elseif indice==9
        
        figure('Name',char(name));
        % Plot the Snowball effect
        hold on
        %Plot time series
        p1=plot(dates,X(:,1),'LineStyle','-','marker','none','Color',[0,0,1],'LineWidth',2.5,'DisplayName','L^*_t + \mu_S''S^*_t + \mu_C''C^*_t - g_t');
        
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',2);    
       
       % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');


        hold off
        xlim([1994 2020]);
        ax=gca;
        ax.XTick=1994:2:2020;

        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);
        legend(p1,'Location','southwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name)));
        end
    
    elseif indice==10
        
        figure('Name',char(name));
        % Plot interest rate gap and macro variables
        hold on
        %Plot time series
        p1=plot(dates,X(:,1),'LineStyle','--','marker','none','Color',[0,0,1],'LineWidth',2.5,'DisplayName','Interest rate gap');
        p2=plot(dates,X(:,2),'LineStyle','-','marker','none','Color',[1,0,0],'LineWidth',2.5,'DisplayName',char(name)); 
 
        line(xlim,[0 0],'Color',[0,0,0],'LineWidth',0.1);

        % ZIRP
        vline(1999.17,2000.50,'g-','ZIRP');

        % QE
        vline(2001.25,2006.17,'k-','QE');

        % CME
        vline(2010.83,2013.25,'r-','CME');

        % QQE
        vline(2013.33,2016,'b-','QQE');

        % QQE with yield curve control
        vline(2016.75,[],'m-','QQE w. YCC');


        hold off
        xlim([1994 2020]);
        ax=gca;
        ax.XTick=1994:2:2020;

        xlabel('Dates','FontWeight','bold','FontSize',22);
        ylabel('%','FontWeight','bold','FontSize',22);
        legend([p1 p2],'Location','southwest');
        legend('boxoff');
        legend('show');
        set(legend,'FontSize',20);
        set(gca,'fontsize',20);
        
        % Save output
        if save_output==1
            fig = gcf;
            fig.PaperPosition = [-11.7,2.48,44.5,24.7];
            print('-dpng','-r100',strcat('Results\MODEL','\',char(name),' vs interest rate gap'));
        end
        
    else
    end
    
else

end